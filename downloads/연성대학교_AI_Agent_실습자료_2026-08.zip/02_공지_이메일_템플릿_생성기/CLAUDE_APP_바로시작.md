# Claude Desktop Cowork 바로 시작 · 공지·이메일 템플릿 생성기

이 실습의 권장 경로는 **Claude Desktop Cowork → 실습 폴더 연결 → `내_작업` 수정 → Live artifact 또는 앱 미리보기 확인 → 사람 승인**입니다.

## 시작 전에 확인할 네 가지

1. 작업 모드는 `Cowork`를 선택합니다.
2. 권한 모드는 `Manually approve(수동 승인)`로 유지합니다.
3. 수정 대상은 `내_작업/index.html`과 사용자가 승인한 새 버전뿐입니다.
4. Live artifact는 앱 안의 미리보기·버전 비교용이며, 최종 제출물은 폴더에 남는 정적 HTML입니다.

## 수업 전 관리자 확인

1. Team 조직의 Owner 또는 Primary Owner가 `Organization settings → Cowork`에서 Cowork를 사용할 수 있게 둡니다.
2. Gmail 연결 확장을 진행한다면 Google Workspace Connector와 actions 허용 범위를 확인합니다.
3. 웹 화면 확인이 필요한 수업이라면 `Organization settings → Claude in Chrome`도 별도로 확인합니다. Cowork와 Claude in Chrome은 서로 다른 관리자 설정입니다.
4. Claude in Chrome은 수업에 필요한 사이트만 허용하고, 로그인·2단계 인증·권한 승인은 교수가 직접 수행합니다.

## 교수자 화면 순서

1. 최신 Claude Desktop을 열고 대학의 Team 조직으로 로그인합니다.
2. 입력창의 모드를 `Cowork`로 선택합니다.
3. 왼쪽의 `Projects`에서 `+`를 누르고 `Use an existing folder`를 선택합니다.
4. 다운로드한 전체 패키지가 아니라 **`02_공지_이메일_템플릿_생성기` 폴더 하나만** 선택합니다.
5. Claude Desktop이 표시하는 폴더 접근 범위를 읽고 승인합니다.
6. Project instructions에는 `PROJECT_INSTRUCTIONS.md` 내용을 사용합니다.
7. 권한 모드를 `Manually approve(수동 승인)`로 선택합니다.
8. `START_PROMPT.md` 전체를 한 번 복사해 보냅니다. `00_먼저읽기.html`의 딥 링크는 요청문만 채우며 폴더를 자동 첨부하지 않습니다.

## Claude가 해야 할 일

1. `CLAUDE_APP_바로시작.md`, `PROJECT_INSTRUCTIONS.md`, `TASKS.md`, `CHECKLIST.md`를 읽습니다.
2. 시작본·중간본·완성본·가상데이터·오류복구의 구조를 확인합니다.
3. 변경 파일, 구현 순서, 자체 검사, 완료 조건을 6줄 이내로 제안하고 **사람의 승인을 기다립니다**.
4. 승인 뒤 `내_작업/index.html` 또는 사용자가 승인한 새 버전만 한 기능씩 수정합니다.
5. 각 기능 뒤 정상 입력·빈 입력·오류 입력·승인 후 수정 흐름을 자체 검사합니다.
6. Live artifact 또는 Claude Desktop 안의 미리보기에서 5개 유형, 제목 3개, 검토 초기화, 예약 상태 모의를 확인합니다.
7. `CHECKLIST.md` 결과, 변경 파일, 남은 한계를 보고하고 최종 승인을 기다립니다.

## Live artifact와 로컬 파일을 구분합니다

- `내_작업/index.html`은 폴더에 남고 `file://`에서 열리는 수업 결과물입니다.
- Live artifact는 Cowork의 Artifacts 화면에서 확인하는 앱 내부 대화형 미리보기입니다.
- Live artifact의 Version history는 비교·복원에 쓸 수 있지만 로컬 파일의 백업을 대신하지 않습니다.
- 실제 수신자·학생정보를 넣은 결과는 Live artifact로 만들거나 조직에 공유하지 않습니다.

## Gmail 연결 확장은 별도 승인 뒤 진행합니다

- Gmail Connector는 send·reply·forward도 지원하지만, **본 실습에서 Connector 행동은 안전상 Draft 생성까지만 허용**합니다.
- Gmail 예약·취소·재예약은 사람이 Gmail 화면에서 수신자·제목·본문·시간대를 다시 확인한 뒤 수행합니다.
- 필요하면 Claude in Chrome으로 Gmail을 열 수 있지만, 로그인과 사이트·행동 승인은 `Manually approve(수동 승인)`에서 사람이 직접 처리합니다.
- 본인이 소유하고 확인할 수 있는 테스트 주소 1건만 사용하며 Cc·Bcc·첨부·단체 주소는 사용하지 않습니다.

## 공통 안전선

- 실제 이름·학번·이메일·성적·상담 내용은 실습 폴더에 넣지 않습니다.
- Claude가 상위 폴더, 다른 앱, 다른 사이트에 대한 접근을 요청하면 거절하고 범위를 실습 폴더로 줄입니다.
- 원본 `시작본/`, `중간본/`, `완성본/`, `가상데이터/`는 수정하지 않습니다.
- 비밀키·OAuth 토큰·client secret·실제 테스트 주소를 코드나 문서에 저장하지 않습니다.

## 공식 안내

- [Claude Cowork 시작하기](https://support.claude.com/en/articles/13345190-get-started-with-claude-cowork)
- [Cowork Project에서 기존 폴더 사용](https://support.claude.com/en/articles/14116274-organize-your-tasks-with-projects-in-claude-cowork)
- [Cowork Live artifacts와 버전 복원](https://support.claude.com/en/articles/14729249-use-live-artifacts-in-claude-cowork)
- [Claude Desktop 딥 링크](https://support.claude.com/en/articles/14729294-open-claude-desktop-with-a-link)
- [Google Workspace Connector](https://support.claude.com/en/articles/10166901-use-google-workspace-connectors)
- [Claude in Chrome 시작하기](https://support.claude.com/en/articles/12012173-get-started-with-claude-in-chrome)
- [Claude in Chrome 권한 모드](https://support.claude.com/en/articles/12902446-claude-in-chrome-permissions-guide)

