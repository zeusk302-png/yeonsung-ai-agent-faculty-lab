/**
 * 교육용 Gmail 예약 발송 예제
 * - 기본값은 DRY_RUN=true입니다.
 * - 본인 테스트 주소 1개만 허용합니다.
 * - Gmail API는 초안 생성/발송을 담당하고, 예약 시각 실행은 Apps Script 시간 트리거가 담당합니다.
 * - 실제 주소, 비밀키, OAuth 토큰을 코드에 적지 마세요.
 */

const PRACTICE = Object.freeze({
  stateKey: 'PRACTICE_STATE_V1',
  triggerHandler: 'sendScheduledDraft',
  minimumDelayMinutes: 5,
  maximumDelayHours: 24,
});

function previewSelfTest() {
  const config = readConfig_();
  validateRecipient_(config);
  const preview = {
    dryRun: config.dryRun,
    recipient: maskEmail_(config.recipient),
    subject: config.subject,
    bodyPreview: config.body.slice(0, 120),
    scheduleAt: config.scheduleAt ? config.scheduleAt.toISOString() : '',
    nextAction: config.dryRun
      ? 'DRY_RUN 상태입니다. 초안·트리거·발송을 만들지 않습니다.'
      : '승인 문구를 직접 입력해 createSelfTestDraft를 실행하세요.',
  };
  appendLog_('PREVIEWED', '설정 미리보기', config.recipient);
  console.log(JSON.stringify(preview, null, 2));
  return preview;
}

function createSelfTestDraft(approvalPhrase) {
  const config = readConfig_();
  validateApproval_(approvalPhrase, config.approvalPhrase);
  validateRecipient_(config);
  const current = readState_();
  if (current.status === 'SENT') {
    throw new Error('SENT 상태는 변경할 수 없습니다. 상태를 확인한 뒤 resetPracticeForNewSelfTest를 명시적으로 실행하세요.');
  }
  if (current.status === 'DRAFT' && current.draftId) {
    return publicState_(current, config.recipient);
  }
  if (current.status === 'SCHEDULED') {
    throw new Error('이미 예약대기 중입니다. 상태를 확인하거나 먼저 예약을 취소하세요.');
  }
  if (current.status === 'FAILED') {
    throw new Error('실패 상태입니다. 보낸편지함을 확인한 뒤 retryFailedSend를 사용하세요.');
  }
  if (current.status === 'CANCELLED') {
    throw new Error('취소된 기존 초안이 남아 있습니다. 같은 초안을 다시 예약하거나 명시적 초기화를 실행하세요.');
  }
  if (current.status === 'DRY_RUN' && !config.dryRun) {
    throw new Error('DRY_RUN 검토가 끝났습니다. 실제 1건을 시작하려면 명시적 초기화를 실행하세요.');
  }
  if (config.dryRun) {
    const state = writeState_({ status: 'DRY_RUN', draftId: '', scheduleAt: '', lastError: '' });
    appendLog_('DRY_RUN', '초안 생성 생략', config.recipient);
    return state;
  }

  const raw = buildRawMessage_(config.recipient, config.subject, config.body);
  const draft = Gmail.Users.Drafts.create({ message: { raw: raw } }, 'me');
  const state = writeState_({ status: 'DRAFT', draftId: draft.id, scheduleAt: '', lastError: '' });
  appendLog_('DRAFT', 'Gmail 초안 생성', config.recipient);
  return publicState_(state, config.recipient);
}

function approveAndScheduleSelfTest(approvalPhrase, scheduleAtIso) {
  const config = readConfig_();
  validateApproval_(approvalPhrase, config.approvalPhrase);
  validateRecipient_(config);
  const scheduleAt = validateSchedule_(scheduleAtIso || getProperty_('SCHEDULE_AT_ISO'));
  const current = readState_();
  if (current.status === 'SENT') {
    throw new Error('SENT 상태는 변경할 수 없습니다. 새 실습은 명시적 초기화 후 시작하세요.');
  }
  if (current.status === 'SCHEDULED') {
    throw new Error('이미 예약대기 중입니다. 중복 예약하지 말고 현재 상태를 확인하세요.');
  }
  if (current.status === 'DRY_RUN' && !config.dryRun) {
    throw new Error('DRY_RUN에서 실제 발송으로 바꾸기 전에 resetPracticeForNewSelfTest를 실행하세요.');
  }

  if (config.dryRun) {
    const state = writeState_({ status: 'DRY_RUN', draftId: '', scheduleAt: scheduleAt.toISOString(), lastError: '' });
    appendLog_('DRY_RUN', '예약 트리거 생성 생략', config.recipient);
    return publicState_(state, config.recipient);
  }

  let state = readState_();
  if (!state.draftId || !['DRAFT', 'FAILED', 'CANCELLED'].includes(state.status)) {
    createSelfTestDraft(approvalPhrase);
    state = readState_();
  }
  clearPracticeTriggers_();
  const trigger = ScriptApp.newTrigger(PRACTICE.triggerHandler).timeBased().at(scheduleAt).create();
  state = writeState_({
    status: 'SCHEDULED',
    draftId: state.draftId,
    triggerId: trigger.getUniqueId(),
    scheduleAt: scheduleAt.toISOString(),
    lastError: '',
  });
  appendLog_('SCHEDULED', '시간 트리거 예약', config.recipient);
  return publicState_(state, config.recipient);
}

function sendScheduledDraft() {
  const lock = LockService.getScriptLock();
  if (!lock.tryLock(5000)) throw new Error('다른 발송 작업이 진행 중입니다. 상태를 확인한 뒤 다시 시도하세요.');
  let attemptedState = null;
  try {
    const config = readConfig_();
    validateRecipient_(config);
    const state = readState_();
    attemptedState = state;
    if (state.status === 'SENT') return publicState_(state, config.recipient);
    if (config.dryRun) {
      appendLog_('DRY_RUN', '트리거 발송 생략', config.recipient);
      return writeState_({ status: 'DRY_RUN', draftId: state.draftId || '', scheduleAt: state.scheduleAt || '', lastError: '' });
    }
    if (state.status !== 'SCHEDULED' || !state.draftId) {
      throw new Error('예약대기 상태의 초안이 없습니다. 상태를 확인하세요.');
    }
    Gmail.Users.Drafts.send({ id: state.draftId }, 'me');
    clearPracticeTriggers_();
    const sent = writeState_({ status: 'SENT', draftId: '', triggerId: '', scheduleAt: state.scheduleAt, lastError: '' });
    appendLog_('SENT', '본인 테스트 1건 발송 완료', config.recipient);
    return publicState_(sent, config.recipient);
  } catch (error) {
    if (!attemptedState || attemptedState.status !== 'SCHEDULED') throw error;
    const config = readConfig_();
    const state = readState_();
    clearPracticeTriggers_();
    const failed = writeState_({
      status: 'FAILED',
      draftId: state.draftId,
      triggerId: '',
      scheduleAt: state.scheduleAt,
      lastError: String(error && error.message ? error.message : error).slice(0, 300),
    });
    appendLog_('FAILED', failed.lastError, config.recipient);
    throw error;
  } finally {
    lock.releaseLock();
  }
}

function cancelScheduledSend(approvalPhrase) {
  const config = readConfig_();
  validateApproval_(approvalPhrase, config.approvalPhrase);
  validateRecipient_(config);
  const current = readState_();
  if (current.status === 'SENT') {
    throw new Error('SENT 상태는 취소하거나 덮어쓸 수 없습니다. 보낸편지함에서 결과를 확인하세요.');
  }
  if (current.status !== 'SCHEDULED') {
    throw new Error('SCHEDULED 상태에서만 예약을 취소할 수 있습니다.');
  }
  clearPracticeTriggers_();
  const cancelled = writeState_({
    status: 'CANCELLED',
    draftId: current.draftId || '',
    triggerId: '',
    scheduleAt: '',
    lastError: '',
  });
  appendLog_('CANCELLED', '예약 취소; Gmail 초안은 보존', config.recipient);
  return publicState_(cancelled, config.recipient);
}

function resetPracticeForNewSelfTest(approvalPhrase, expectedCurrentStatus) {
  const config = readConfig_();
  validateApproval_(approvalPhrase, config.approvalPhrase);
  validateRecipient_(config);
  const current = readState_();
  const expected = String(expectedCurrentStatus || '').trim().toUpperCase();
  const allowedTerminalStates = ['EMPTY', 'DRY_RUN', 'CANCELLED', 'SENT'];
  if (!expected || current.status !== expected) {
    throw new Error('현재 상태를 직접 확인한 뒤 두 번째 인수에 정확히 입력하세요. 예: SENT');
  }
  if (hasPracticeTriggers_()) {
    throw new Error('남아 있는 예약 트리거가 있습니다. 상태와 예약을 확인한 뒤 초기화하세요.');
  }
  if (!allowedTerminalStates.includes(current.status)) {
    throw new Error('진행 중이거나 실패 여부가 불명확한 상태에서는 초기화할 수 없습니다.');
  }
  const reset = writeState_({ status: 'EMPTY', draftId: '', triggerId: '', scheduleAt: '', lastError: '' });
  appendLog_('RESET', '상태 확인 후 새 본인 테스트 준비', config.recipient);
  return publicState_(reset, config.recipient);
}

function retryFailedSend(approvalPhrase, scheduleAtIso) {
  const state = readState_();
  if (state.status !== 'FAILED') {
    throw new Error('FAILED 상태에서만 재시도할 수 있습니다.');
  }
  return approveAndScheduleSelfTest(approvalPhrase, scheduleAtIso);
}

function getPracticeStatus() {
  const config = readConfig_();
  return {
    state: publicState_(readState_(), config.recipient),
    log: readLog_(),
    dryRun: config.dryRun,
  };
}

function readConfig_() {
  return {
    dryRun: getProperty_('DRY_RUN', 'true').toLowerCase() !== 'false',
    recipient: getProperty_('SELF_TEST_RECIPIENT').trim().toLowerCase(),
    allowlist: getProperty_('SELF_TEST_ALLOWLIST').trim().toLowerCase(),
    approvalPhrase: getProperty_('APPROVAL_PHRASE'),
    subject: getProperty_('TEST_SUBJECT', '[연습] 공지 이메일 예약 발송'),
    body: getProperty_('TEST_BODY', '가상 정보로 만든 교수자 실습용 테스트 메일입니다.'),
    scheduleAt: getProperty_('SCHEDULE_AT_ISO') ? new Date(getProperty_('SCHEDULE_AT_ISO')) : null,
  };
}

function validateRecipient_(config) {
  const emailPattern = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  if (!emailPattern.test(config.recipient) || config.recipient !== config.allowlist) {
    throw new Error('SELF_TEST_RECIPIENT와 SELF_TEST_ALLOWLIST에 동일한 본인 주소 1개를 입력하세요.');
  }
  if (/[;,\s]/.test(config.recipient)) {
    throw new Error('수신자는 본인 주소 1개만 허용합니다.');
  }
}

function validateApproval_(actual, expected) {
  if (!expected || actual !== expected) {
    throw new Error('스크립트 속성의 승인 문구와 정확히 같은 문구를 직접 입력해야 합니다.');
  }
}

function validateSchedule_(isoText) {
  const scheduled = new Date(isoText);
  if (!isoText || Number.isNaN(scheduled.getTime())) {
    throw new Error('시간대가 포함된 ISO 예약 시각을 입력하세요. 예: 2026-08-20T15:30:00+09:00');
  }
  const now = Date.now();
  const minimum = now + PRACTICE.minimumDelayMinutes * 60 * 1000;
  const maximum = now + PRACTICE.maximumDelayHours * 60 * 60 * 1000;
  if (scheduled.getTime() < minimum || scheduled.getTime() > maximum) {
    throw new Error('예약은 현재 시각에서 5분 이후, 24시간 이내만 허용합니다.');
  }
  return scheduled;
}

function buildRawMessage_(to, subject, body) {
  const safeSubject = String(subject).replace(/[\r\n]+/g, ' ').trim();
  const encodedSubject = '=?UTF-8?B?' + Utilities.base64Encode(safeSubject, Utilities.Charset.UTF_8) + '?=';
  const message = [
    'To: ' + to,
    'Subject: ' + encodedSubject,
    'MIME-Version: 1.0',
    'Content-Type: text/plain; charset=UTF-8',
    '',
    body,
  ].join('\r\n');
  return Utilities.base64EncodeWebSafe(message, Utilities.Charset.UTF_8).replace(/=+$/, '');
}

function clearPracticeTriggers_() {
  ScriptApp.getProjectTriggers().forEach(function (trigger) {
    if (trigger.getHandlerFunction() === PRACTICE.triggerHandler) {
      ScriptApp.deleteTrigger(trigger);
    }
  });
}

function hasPracticeTriggers_() {
  return ScriptApp.getProjectTriggers().some(function (trigger) {
    return trigger.getHandlerFunction() === PRACTICE.triggerHandler;
  });
}

function readState_() {
  const raw = PropertiesService.getScriptProperties().getProperty(PRACTICE.stateKey);
  return raw ? JSON.parse(raw) : { status: 'EMPTY', draftId: '', triggerId: '', scheduleAt: '', lastError: '' };
}

function writeState_(patch) {
  const next = Object.assign({}, readState_(), patch, { updatedAt: new Date().toISOString() });
  PropertiesService.getScriptProperties().setProperty(PRACTICE.stateKey, JSON.stringify(next));
  return next;
}

function publicState_(state, recipient) {
  return {
    status: state.status,
    recipient: maskEmail_(recipient),
    scheduleAt: state.scheduleAt || '',
    lastError: state.lastError || '',
    hasDraft: Boolean(state.draftId),
    updatedAt: state.updatedAt || '',
  };
}

function appendLog_(status, message, recipient) {
  const entries = readLog_();
  entries.push({ at: new Date().toISOString(), status: status, message: String(message).slice(0, 300), recipient: maskEmail_(recipient) });
  PropertiesService.getScriptProperties().setProperty('PRACTICE_LOG_V1', JSON.stringify(entries.slice(-30)));
}

function readLog_() {
  const raw = PropertiesService.getScriptProperties().getProperty('PRACTICE_LOG_V1');
  return raw ? JSON.parse(raw) : [];
}

function maskEmail_(email) {
  if (!email || email.indexOf('@') < 1) return '(미설정)';
  const parts = email.split('@');
  return parts[0].slice(0, 2) + '***@' + parts[1];
}

function getProperty_(key, fallback) {
  const value = PropertiesService.getScriptProperties().getProperty(key);
  return value === null || value === '' ? (fallback || '') : value;
}
