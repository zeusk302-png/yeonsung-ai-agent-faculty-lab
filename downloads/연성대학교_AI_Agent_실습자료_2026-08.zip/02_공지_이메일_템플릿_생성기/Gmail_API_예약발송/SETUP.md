# Gmail API 예약 발송 · 고급 선택 실습

이 폴더는 필수 실습이 아닙니다. 대학이 Apps Script와 Gmail API 사용을 허용했고, 강사가 별도로 안내한 경우에만 본인 테스트 주소 1건으로 진행합니다.

## 먼저 구분하기

- Gmail API: 초안 생성과 초안 발송을 수행합니다.
- 예약 시각 실행: Gmail API의 예약 기능이 아니라 Apps Script의 설치형 시간 트리거가 수행합니다.
- Apps Script 트리거는 정확한 초 단위 실행을 보장하는 예약 서비스가 아닙니다. 수업에서는 지연 가능성을 감안하고, 일반 사용자는 Gmail 화면의 `보내기 예약`을 우선합니다.
- Claude Google Workspace Connector: Gmail 검색·읽기·Draft 생성과 send·reply·forward를 지원합니다. 기본적으로 행동 전 승인을 요청하고, Team·Enterprise Owner가 actions 허용 범위를 정할 수 있습니다. 본 실습에서 Connector 행동은 안전상 Draft 생성까지만 허용하며 Gmail 예약·취소·재예약은 사람이 화면에서 확인합니다.
- 가장 쉬운 예약 경로: Gmail에서 초안을 연 뒤 `보내기` 옆 화살표 → `보내기 예약`을 사용합니다.

## 1. 새 Apps Script 프로젝트 만들기

1. 본인의 학교 Google 계정으로 Apps Script를 엽니다.
2. 새 프로젝트를 만들고 이름을 `교수자_본인메일_예약실습`으로 정합니다.
3. 기본 `Code.gs` 내용을 이 폴더의 `Code.gs`로 바꿉니다.
4. 프로젝트 설정에서 `appsscript.json` 표시를 켠 뒤 이 폴더의 manifest 내용으로 바꿉니다.
5. 서비스 추가에서 Gmail API가 활성화되었는지 확인합니다.

## 2. 스크립트 속성 입력

`CONFIG_SAMPLE.md`에서 속성 이름과 형식을 확인한 뒤 프로젝트 설정 → 스크립트 속성에 하나씩 직접 등록합니다. 실제 주소·승인 문구는 설정 화면에만 입력하고 문서나 코드에 저장하지 않습니다.

- `DRY_RUN`: 첫 실행은 반드시 `true`
- `SELF_TEST_RECIPIENT`: 본인이 직접 확인할 수 있는 주소 1개
- `SELF_TEST_ALLOWLIST`: 위 주소와 정확히 같은 값
- `APPROVAL_PHRASE`: 화면을 보며 직접 입력할 긴 승인 문구
- `TEST_SUBJECT`, `TEST_BODY`: 가상 정보만 포함한 시험 메일
- `SCHEDULE_AT_ISO`: 현재에서 5분 이후, 24시간 이내이며 시간대가 포함된 ISO 시각

주소·토큰·비밀키를 `Code.gs`, 화면 캡처, Git 저장소에 넣지 않습니다.

## 3. DRY RUN 확인

1. `previewSelfTest`를 실행하고 권한 안내를 읽습니다.
2. 실행 로그에서 수신자가 가려져 보이는지 확인합니다.
3. `createSelfTestDraft('내 승인 문구')`를 실행합니다.
4. 반환 상태가 `DRY_RUN`인지 확인합니다. 이 단계에서는 Gmail 초안과 트리거가 생기지 않습니다.

## 4. 실제 본인 테스트 1건

1. 강사와 함께 설정을 다시 확인합니다.
2. `getPracticeStatus()`로 현재 상태가 `DRY_RUN`이고 예약 트리거가 없음을 확인합니다.
3. `resetPracticeForNewSelfTest('내 승인 문구', 'DRY_RUN')`을 실행합니다.
4. 상태가 `EMPTY`로 바뀐 뒤에만 `DRY_RUN=false`로 바꿉니다.
5. `createSelfTestDraft('내 승인 문구')`를 실행합니다.
6. Gmail 임시보관함에서 수신자·제목·본문을 직접 확인합니다.
7. `approveAndScheduleSelfTest('내 승인 문구', '예약 ISO 시각')`을 실행합니다.
8. `getPracticeStatus()`가 `SCHEDULED`인지 확인합니다.
9. 예약 시각 뒤 본인 받은편지함과 상태 `SENT`를 확인합니다.

## 취소와 재시도

- 예약 취소: `cancelScheduledSend('내 승인 문구')`. 시간 트리거만 지우고 초안은 보존합니다.
- `SENT` 상태는 취소하거나 덮어쓸 수 없습니다.
- 실패 확인: `getPracticeStatus()`에서 `FAILED`와 오류 요약을 봅니다.
- 재시도: 원인을 수정하고 새 예약 시각으로 `retryFailedSend('내 승인 문구', '예약 ISO 시각')`을 실행합니다.
- 새 테스트 시작: 상태와 남은 트리거를 먼저 확인한 뒤 `resetPracticeForNewSelfTest('내 승인 문구', '현재 상태')`를 실행합니다. `EMPTY / DRY_RUN / CANCELLED / SENT`에서만 허용됩니다.
- 여러 번 누르지 않습니다. 한 번 실행한 뒤 상태를 먼저 확인합니다.

## 공식 안내

- [Claude Google Workspace Connector](https://support.claude.com/en/articles/10166901-use-google-workspace-connectors)
- [Claude in Chrome 시작하기](https://support.claude.com/en/articles/12012173-get-started-with-claude-in-chrome)
- [Claude in Chrome 권한 안내](https://support.claude.com/en/articles/12902446-claude-in-chrome-permissions-guide)
- [Gmail API로 메일 보내기](https://developers.google.com/workspace/gmail/api/guides/sending)
- [Apps Script 설치형 트리거](https://developers.google.com/apps-script/guides/triggers/installable)
- [Gmail 보내기 예약](https://support.google.com/mail/answer/9214606)
