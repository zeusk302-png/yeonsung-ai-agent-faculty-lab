# 실습 1 · 공지·이메일 템플릿 생성기

## 앱에서 바로 시작

- `Cowork`: Claude Desktop에서 이 실습 폴더 하나를 Project로 연결합니다.
- `Manually approve(수동 승인)`: 파일·Connector·브라우저 행동을 사람이 매번 확인합니다.
- `내_작업`: Claude가 수정할 기본 대상은 `내_작업/index.html`입니다.
- `Live artifact`: 앱 안에서 미리보기와 버전 비교에 사용하며, 최종 결과물은 폴더의 정적 HTML입니다.

`CLAUDE_APP_바로시작.md`를 먼저 읽고 `START_PROMPT.md`로 시작합니다. Claude Desktop Cowork를 기본 경로로 사용해 5개 공지 유형을 지원하는 로컬 시제품을 만듭니다. 필수 실습은 공지 문구를 만들고 사람이 검토·승인한 뒤 Gmail 초안으로 옮기는 안전한 흐름입니다. 연결 확장에서는 Cowork의 Gmail Connector로 Draft를 만들고, 필요하면 Claude in Chrome으로 Gmail을 연 뒤 사람이 로그인·검토하여 예약합니다. Gmail Connector는 send·reply·forward도 지원하지만, 본 실습에서 Connector 행동은 안전상 Draft 생성까지만 허용합니다. Gmail 예약·취소·재예약과 최종 발송 여부는 사람이 본인 테스트 주소 1건으로 직접 확인합니다.

수업 시간은 `핵심 60분 + 연결 확장 15분`으로 구분합니다. 핵심 60분은 가상 정보와 로컬 상태 모의만 사용하며 외부 전송이 없습니다. 60~75분 연결 확장은 허용된 계정의 본인 테스트 주소 1건만 사용합니다. Apps Script 고급 경로는 별도 선택 자료입니다.

## 시작

`00_먼저읽기.html`을 더블클릭합니다. 이전 주소와의 호환을 위해 `00_바로열기.html`도 같은 안내를 엽니다.

## 권장 경로

1. Claude Desktop에서 Cowork를 선택하고 `02_공지_이메일_템플릿_생성기` 폴더 하나를 연결합니다.
2. Project 지침에는 `PROJECT_INSTRUCTIONS.md`를 사용하고 권한은 `Manually approve(수동 승인)`로 둡니다.
3. `START_PROMPT.md`를 보내 설계안만 먼저 받고, `내_작업/index.html` 외의 원본은 수정하지 않게 합니다.
4. 설계안을 확인한 뒤 2단계 요청으로 새 작업 파일을 만듭니다.
5. Live artifact 또는 앱 미리보기와 `CHECKLIST.md`로 정상·오류·재검토 흐름을 확인합니다.
6. 연결이 허용된 참여자만 `03_Gmail_연결_경로.html`에서 초안·예약 발송 절차를 확인합니다.

Cowork가 보이지 않으면 Claude 웹 Project에 `PROJECT_INSTRUCTIONS.md`, `내_작업` 복사본, 가상 사례를 넣고 같은 승인·검사 순서를 따릅니다.

Claude Code는 설치와 파일 작업에 익숙한 참여자만 선택합니다. 기본 수업 경로가 아니며, 사용할 경우에도 `CLAUDE.md`의 제한을 먼저 읽습니다.

## 폴더 구성

- `00_먼저읽기.html` — 준비물, 안전선, 60분 지도
- `CLAUDE_APP_바로시작.md` — Claude Desktop Cowork 폴더 연결·권한·Live artifact 안내
- `START_PROMPT.md` — Cowork에서 한 번 복사할 시작 요청문
- `01_단계별_안내.html` — 화면을 보며 따라 하는 순서
- `02_복사_프롬프트.html` — 단계별 요청문과 복사 버튼
- `03_Gmail_연결_경로.html` — Cowork Connector Draft와 Gmail 사람 검토·예약 경로
- `Gmail_API_예약발송/` — Apps Script 시간 트리거를 이용한 고급 선택 실습
  - `CONFIG_SAMPLE.md` — 실제 주소·비밀 없이 스크립트 속성 이름과 입력 방법만 안내
- `PROJECT_INSTRUCTIONS.md` — Claude 웹 Project용 지침
- `CLAUDE.md` — Claude Code 선택 경로용 제한
- `TASKS.md` — 필수·선택 작업표
- `CHECKLIST.md` — 완료 판정표
- `가상데이터/` — 실제 사람과 연결되지 않는 사례와 오류 사례
- `내_작업/` — 수업 중 실제로 수정하는 작업 복사본
- `시작본/` — 수정하지 않는 비교·복구용 원본
- `중간본/` — 유형·어조·누락 확인과 검토 상태가 추가된 체크포인트
- `완성본/` — 5개 유형, 제목 3개, 3문단, 재검토, 승인·예약 상태 모의 흐름
- `오류복구/` — 막힌 단계에서 다시 시작하는 자료

## 고정하는 5개 공지 유형

`오리엔테이션 / 세미나·특강 / 휴강 / 보강 / 학사일정`

## 절대 사용하지 않는 것

- 실제 학생 이름·학번·이메일·상담·성적
- 실제 단체 메일링 목록
- 실제 학생·교직원 주소 또는 단체 메일링 목록
- 비밀키·OAuth 토큰·개인 계정 정보의 파일 저장
- 승인 없는 자동 발송, 본인 테스트 주소 외 발송, 공개 게시
- 원본 파일 덮어쓰기

핵심 결과물은 교육용 정적 HTML이며 `file://`에서 실행됩니다. 화면의 예약·발송 상태는 안전한 모의 동작입니다. 실제 Gmail 경로는 연결 확장 15분의 별도 안내에 따라 사람이 Gmail 화면에서 확인하며, 고급 Apps Script 경로는 기본값 `DRY_RUN=true`에서 시작합니다.
