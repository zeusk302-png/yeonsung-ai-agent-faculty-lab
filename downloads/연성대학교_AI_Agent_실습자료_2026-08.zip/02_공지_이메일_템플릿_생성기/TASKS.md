# 실습 1 작업표

## 시작 전 · 앱 경로 고정

- [ ] Claude Desktop에서 `Cowork`를 선택하고 이 실습 폴더 하나만 연결했다.
- [ ] 권한을 `Manually approve(수동 승인)`로 두었다.
- [ ] 수정 대상이 `내_작업/index.html`이고 시작본·중간본·완성본은 읽기 전용임을 확인했다.
- [ ] Live artifact는 미리보기·버전 비교용이고 최종 결과물은 로컬 HTML임을 구분했다.
- [ ] `START_PROMPT.md`를 보내고 변경 계획을 승인하기 전에는 파일을 수정하지 않게 했다.

## 핵심 60분 · 외부 전송 없음

- [ ] 완성본에서 5개 공지 유형과 상태 흐름을 확인한다.
- [ ] Cowork Project에 `PROJECT_INSTRUCTIONS.md`를 적용한다. Cowork가 없을 때만 웹 Project를 대체 경로로 사용한다.
- [ ] `내_작업/index.html`, 테마, 가상 사례를 읽고 `시작본/`은 복구용으로 남긴다.
- [ ] 설계안만 먼저 받고 구현 순서를 확인한다.
- [ ] 새 버전 파일에 5개 유형과 3개 어조를 만든다.
- [ ] 제목 후보 3개와 세 문단 본문을 만든다.
- [ ] 필수값 누락 시 추측하지 않고 안내한다.
- [ ] 검토표를 모두 확인하기 전 승인할 수 없게 한다.
- [ ] 제목·본문 수정 시 이전 승인을 무효화한다.
- [ ] 예약 대기, 취소, 실패, 재시도, 기록 상태를 로컬에서 시험한다.
- [ ] `CHECKLIST.md`의 필수 항목을 확인한다.
- [ ] Live artifact 또는 앱 미리보기에서 핵심 동작을 확인하고 Version history 위치를 확인한다.

## 연결 확장 15분 · 60~75분

- [ ] 대학 Owner가 Claude Google Workspace Connector와 actions를 어디까지 허용했는지 확인한다.
- [ ] Gmail Connector는 send·reply·forward도 지원하지만, 본 실습에서 Connector 행동은 안전상 Draft 생성까지만 허용된다는 점을 확인한다.
- [ ] Claude Desktop Cowork에서 Gmail Connector를 켜고 Gmail Draft 1건만 만들도록 요청한다.
- [ ] 필요하면 Claude in Chrome으로 Gmail을 열되 사람이 로그인하고 `Manually approve(수동 승인)`와 대상 사이트를 확인한다.
- [ ] Gmail Draft에서 수신자·제목·본문을 사람이 다시 확인한다.
- [ ] Gmail 화면의 `Send` 옆 화살표에서 `Schedule send`를 선택한다.
- [ ] Scheduled 폴더에서 예약을 확인하고 취소 방법을 시험한다.
- [ ] 강사 확인 뒤 다시 예약해 본인 받은편지함에 정확히 1건이 도착했는지 확인한다.

## 수업 후 고급 선택

- [ ] `Gmail_API_예약발송/SETUP.md`를 읽고 관리자 허용 여부를 확인한다.
- [ ] 실제 주소를 소스가 아닌 Script Properties에 저장한다.
- [ ] `DRY_RUN=true`로 미리보기와 allowlist 차단을 시험한다.
- [ ] 허용된 경우에만 본인 테스트 주소 1건을 예약·발송한다.
- [ ] 상태·실패·재시도·취소 기록을 확인한다.
- [ ] `SENT` 상태는 취소·덮어쓰기가 거부되는지 확인한다.
- [ ] 새 테스트는 현재 상태와 남은 트리거를 확인한 뒤 명시적 reset으로만 시작한다.

## 하지 않는 일

- 실제 수강생·교직원·외부기관 주소 사용
- 단체 수신, Cc/Bcc, 첨부, 대량 발송
- 비밀키·토큰·실제 주소를 파일이나 화면 캡처에 기록
- 수업 중 만든 시제품을 검토 없이 실제 업무에 투입
