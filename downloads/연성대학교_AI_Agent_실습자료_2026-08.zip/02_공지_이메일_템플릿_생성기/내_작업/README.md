# 내 작업 폴더

이 폴더의 `index.html`을 Chrome 또는 Edge로 열고 수정합니다. `시작본`은 복구용으로 그대로 두세요.

1. 상위 폴더의 `00_먼저읽기.html`과 `CLAUDE_APP_바로시작.md`를 엽니다.
2. Claude Desktop Cowork에서 실습 폴더를 연결하고 `PROJECT_INSTRUCTIONS.md`를 Project 지침으로 사용합니다.
3. `Manually approve(수동 승인)`를 선택하고 `START_PROMPT.md`로 시작합니다.
4. Live artifact 또는 앱 미리보기에서 확인하되 최종 파일은 이 `내_작업` 폴더에 남깁니다.
5. 화면이 망가지면 이 폴더를 지우지 말고, `시작본`의 내용을 다시 복사해 새 폴더에서 이어갑니다.

실제 수신자 주소를 코드에 넣지 않습니다. 연결 실습은 본인이 확인할 수 있는 주소 1개만 사용합니다.
