# 실습 결과물 03 · 맞춤형 수업 도구

## 권장 실행 환경 · Claude Desktop Cowork

Claude Desktop에서 Cowork Project를 만들고 `Use an existing folder`로 이 실습 폴더를 사람이 직접 연결합니다. `CLAUDE_APP_바로시작.md`의 화면 순서를 확인한 뒤 `START_PROMPT.md`를 한 번 복사합니다. 권한 모드는 `Manually approve(수동 승인)`로 유지하며, Claude가 계획을 제시하면 사람이 승인하고 `내_작업/index.html`만 수정하게 합니다. 결과는 Live artifact 또는 앱 내부 미리보기에서 확인하고 필요하면 이전 버전을 복원합니다.

퀴즈, 타이머, 무작위 모둠 구성, 가상 피드백 그래프를 한 화면에서 실행하는 정적 HTML 앱입니다. 서버·로그인·외부 데이터 연결 없이 더블클릭으로 사용할 수 있습니다.

수업 시간은 `핵심 60분 + 반복·개인화 15분`입니다. 60분에 네 기능과 오류 처리를 완성하고 저장합니다. 60~75분에는 문항 1개 변경, 오류·초기화 재검증, 30초 결과 설명을 진행합니다.

## 여는 순서

1. `00_먼저읽기.html`을 더블클릭합니다. `00_바로열기.html`도 같은 화면을 엽니다.
2. Claude Desktop Cowork Project에 기존 실습 폴더를 연결합니다. Desktop을 사용할 수 없을 때만 Claude 웹 Project에 `PROJECT_INSTRUCTIONS.md`, `내_작업/`, `가상데이터/`를 첨부합니다. `시작본/`은 비교·복구용으로 보존합니다.
3. `02_복사_프롬프트.html`의 요청을 한 단계씩 사용합니다.
4. 기능이 멈추면 `오류복구/00_문제해결_안내.html`에서 가장 가까운 중간본으로 돌아갑니다.

## Claude에 내 수업용 제작 요청하기

Claude Desktop Cowork Project가 기본 경로입니다. `PROJECT_INSTRUCTIONS.md`는 이 과제의 안전선과 완료 조건을 유지합니다. Claude 웹 Project와 Claude Code는 대체·선택 경로입니다.

## 폴더 구성

- `00_먼저읽기.html` — 60분 경로와 실습 안전선
- `01_단계별_안내.html` — 화면을 보며 따라 하는 제작 순서
- `02_복사_프롬프트.html` — 설계·구현·검사용 단계별 요청문
- `PROJECT_INSTRUCTIONS.md` — Claude 웹 Project용 고정 지침
- `CLAUDE.md` — Claude Code 선택 경로용 제한
- `TASKS.md`, `CHECKLIST.md` — 시간표와 완료 판정표
- `가상데이터/` — 퀴즈·S001~S012·피드백·오류 CSV
- `내_작업/` — 수업 중 실제로 수정하는 작업 복사본
- `시작본/` — 수정하지 않는 비교·복구용 원본
- `중간본/` — 퀴즈·타이머와 모둠·피드백 체크포인트
- `완성본/` — 네 기능이 합쳐진 비교용 결과
- `오류복구/` — 증상별 되돌리기와 복구 요청문

## 완성본 기능

- 퀴즈: 세 개 가상 문항, 선택 즉시 피드백, 전체 결과, 다시 풀기
- 타이머: 분·초 설정, 시작, 일시정지, 확인 후 초기화, 직전 상태 1회 복원
- 모둠 구성: 가상 ID 형식 확인, 중복 확인, 무작위 균형 배정
- 피드백: 세 범주와 짧은 가상 의견, 막대그래프 즉시 갱신, 전체 지우기 직전 상태 1회 복원

## 데이터 범위

- 실제 학생 이름, 학번, 이메일, 전화번호, 성적, 상담 내용은 사용하지 않습니다.
- 모둠 구성에는 S001처럼 실제와 연결되지 않는 가상 ID만 사용합니다.
- 피드백과 모둠 결과는 현재 화면 메모리에만 있으며 새로고침하면 사라집니다.
- 초기화·전체 지우기의 실행 취소 상태도 현재 화면 메모리에만 있으며 새로고침하면 사라집니다.
- 여러 사용자가 동시에 참여하는 실시간 서비스가 아닙니다. “즉시 반영”은 같은 브라우저 화면 안에서 버튼을 누른 결과가 바로 바뀐다는 뜻입니다.
- 외부 서버·로그인·API·추적 도구를 추가하지 않습니다.

## 완료 기준

- 네 기능이 각각 정상·빈 입력·오류 상태를 설명합니다.
- 가상 피드백을 추가하면 같은 화면의 그래프가 즉시 바뀝니다.
- 개인정보로 보일 수 있는 일부 입력 형식을 거부합니다.
- 기능 실패 시 초기화하거나 가상 예시로 돌아갈 수 있습니다.

## 문제 해결과 공식 안내

- [Claude Cowork 시작하기](https://support.claude.com/en/articles/13345190-get-started-with-claude-cowork)
- [Cowork Project에서 기존 폴더 사용](https://support.claude.com/en/articles/14116274-organize-your-tasks-with-projects-in-claude-cowork)
- [Cowork Live artifacts와 버전 복원](https://support.claude.com/en/articles/14729249-use-live-artifacts-in-claude-cowork)
- [Claude in Chrome 시작하기](https://support.claude.com/en/articles/12012173-get-started-with-claude-in-chrome)
- [Team·Enterprise Cowork 관리자 설정](https://support.claude.com/en/articles/13455879-use-claude-cowork-on-team-and-enterprise-plans)
- [Claude Desktop 딥 링크](https://support.claude.com/en/articles/14729294-open-claude-desktop-with-a-link)
