# Claude Desktop Cowork 바로 시작 · 학생 성취도 분석

이 실습은 **Claude Desktop 안에서 폴더 연결 → 제작 → 미리보기 → 자체 검사 → 사람 승인**까지 이어지는 경로를 권장합니다.

## 수업 전 관리자 확인

1. Team 조직의 Owner 또는 Primary Owner가 `Organization settings → Cowork`에서 Cowork를 사용할 수 있게 둡니다.
2. 웹 화면 확인이 필요한 수업이라면 `Organization settings → Claude in Chrome`도 별도로 확인합니다. Cowork와 Claude in Chrome은 서로 다른 관리자 설정입니다.
3. Claude in Chrome은 수업에 필요한 사이트만 허용하도록 allowlist를 좁게 시작합니다.
4. Connector의 쓰기 동작은 매 작업 승인을 유지합니다. 조직에서 “항상 허용”을 허용하더라도 수업에서는 `Manually approve(수동 승인)`을 사용합니다.

## 교수자 화면 순서

1. 최신 Claude Desktop을 열고 대학의 Team 조직으로 로그인합니다.
2. 입력창의 모드를 `Cowork`로 선택합니다.
3. 왼쪽의 `Projects`에서 `+`를 누르고 `Use an existing folder`를 선택합니다.
4. 다운로드한 실습자료 전체가 아니라 **`04_학생_성취도_분석_웹앱` 폴더 하나만** 직접 선택합니다.
5. Claude Desktop이 표시하는 폴더 접근 범위를 읽고 승인합니다. 딥 링크 버튼은 요청문만 채우며 폴더를 자동 첨부하지 않습니다.
6. Project instructions에는 `PROJECT_INSTRUCTIONS.md` 내용을 사용합니다.
7. 권한 모드를 `Manually approve(수동 승인)`로 선택합니다.
8. `START_PROMPT.md` 전체를 한 번 복사해 보냅니다.

## Claude가 해야 할 일

1. `CLAUDE_APP_바로시작.md`, `PROJECT_INSTRUCTIONS.md`, `TASKS.md`, `CHECKLIST.md`, 데이터사전을 읽습니다.
2. 시작본·중간 체크포인트·완성본·정상 및 오류 CSV의 구조를 확인합니다.
3. 변경 파일, 데이터 검사, 계산 추적, 검토 상태, 완료 조건을 6줄 이내로 제안하고 **사람의 승인을 기다립니다**.
4. 승인 뒤 `내_작업/index.html`만 한 단계씩 수정합니다.
5. L-001~L-010, 한글 5열, 35/35/15/15, 70/60 기준을 바꾸지 않고 자체 검사합니다.
6. Live artifact 또는 제공되는 앱 내부 미리보기에서 기준값 변경, 원자료·계산식 추적, 승인·수정·보류, 승인 항목만 내보내기를 확인합니다.
7. `CHECKLIST.md` 결과, 변경 파일, 남은 한계를 보고하고 최종 승인을 기다립니다.

## Live artifact와 로컬 파일을 구분합니다

- `내_작업/index.html`은 폴더에 남는 로컬 실습 파일입니다.
- Live artifact는 Cowork의 Artifacts 화면에 저장되는 앱 내부 대화형 결과입니다.
- Live artifact를 수정할 때마다 버전이 남으므로, 잘못된 변경은 Version history에서 비교하고 복원할 수 있습니다.
- Team/Enterprise에서는 조직 안에서 Live artifact를 공유할 수 있지만, 실제 학생자료를 넣은 결과는 공유하지 않습니다.

## 웹 확인이 필요할 때만 Claude in Chrome

- Claude in Chrome은 **Chrome 확장 프로그램**입니다. Cowork에서 호출하면 창을 오가며 복사하는 일을 줄일 수 있습니다.
- Team/Enterprise에는 전체 컴퓨터 사용 기능이 제공되지 않습니다. Claude in Chrome을 전체 컴퓨터 제어라고 설명하지 않습니다.
- 확장 프로그램 설치, 조직 enable, 사이트 allowlist, 해당 대화의 Connector 선택이 모두 충족되어야 합니다.
- 로그인·비밀번호·2단계 인증과 권한 승인은 교수가 직접 수행합니다.
- 승인 모드는 `Manually approve(수동 승인)`로 유지하고 요청한 사이트·행동만 한 번씩 허용합니다.

## 수업 공통 안전선

- Gmail Connector에는 발송·회신·전달 기능이 있지만, 본 교육에서는 **Draft 생성까지만** 사용합니다. 실제 발송은 사람이 Gmail에서 내용을 다시 확인한 뒤 직접 결정합니다.
- ‘지원 확인 필요’는 교수자가 원자료를 다시 볼 참고 신호이며 자동 판정이 아닙니다.
- 실제 이름·학번·이메일·성적·상담 내용은 실습 폴더에 넣지 않습니다.
- Claude가 더 넓은 상위 폴더, 다른 앱, 다른 사이트 접근을 요청하면 거절하고 실습 폴더로 범위를 줄입니다.
- 원본·시작본·중간 체크포인트·완성본을 수정하지 않습니다.

## 막혔을 때

1. Claude Desktop과 Chrome 확장을 최신 버전으로 다시 시작합니다.
2. Team 조직을 선택했는지, Cowork와 Claude in Chrome이 관리자에게 각각 허용됐는지 확인합니다.
3. Cowork Project의 연결 폴더가 `04_학생_성취도_분석_웹앱`인지 확인합니다.
4. Claude in Chrome이 보이지 않으면 Desktop `Settings → Connectors`에서 별도로 구성하고 해당 대화에서 켭니다.
5. 자동 승인을 켜지 말고 `Manually approve(수동 승인)`에서 필요한 행동만 다시 허용합니다.

## 공식 안내

- [Claude Cowork 시작하기](https://support.claude.com/en/articles/13345190-get-started-with-claude-cowork)
- [Cowork Project에서 기존 폴더 사용](https://support.claude.com/en/articles/14116274-organize-your-tasks-with-projects-in-claude-cowork)
- [Cowork Live artifacts와 버전 복원](https://support.claude.com/en/articles/14729249-use-live-artifacts-in-claude-cowork)
- [Claude in Chrome 시작하기](https://support.claude.com/en/articles/12012173-get-started-with-claude-in-chrome)
- [Claude in Chrome 권한 모드](https://support.claude.com/en/articles/12902446-claude-in-chrome-permissions-guide)
- [Claude in Chrome 관리자 설정과 allowlist](https://support.claude.com/en/articles/13065128-claude-in-chrome-admin-controls)
- [Team·Enterprise Cowork 관리자 설정](https://support.claude.com/en/articles/13455879-use-claude-cowork-on-team-and-enterprise-plans)
- [컴퓨터 사용 제공 범위](https://support.claude.com/en/articles/14128542-let-claude-use-your-computer-in-cowork)
- [Google Workspace Connector](https://support.claude.com/en/articles/10166901-use-google-workspace-connectors)
- [Claude Desktop 딥 링크](https://support.claude.com/en/articles/14729294-open-claude-desktop-with-a-link)
