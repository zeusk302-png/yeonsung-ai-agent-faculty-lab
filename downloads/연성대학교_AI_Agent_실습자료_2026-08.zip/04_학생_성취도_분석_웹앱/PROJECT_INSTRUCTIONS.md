# Claude 웹 작업 지침 · 실습 3

## 권장 앱 우선 경로

이 문서는 Claude Desktop의 **Cowork Project**에서 사용하는 것이 기본입니다. Projects의 `+`에서 `Use an existing folder`를 선택하고 이 실습 폴더만 사람이 직접 연결합니다. 권한 모드는 `Manually approve(수동 승인)`로 두고, Claude는 먼저 계획을 제시한 뒤 사람의 승인을 기다립니다. 원본·시작본·중간 체크포인트·완성본은 보존하고 `내_작업/index.html`만 수정합니다. Claude 웹은 Desktop을 사용할 수 없을 때의 대체 경로입니다.

앱 내부 Live artifact 또는 미리보기에서 결과를 확인하고, 변경이 잘못되면 버전 기록에서 이전 버전을 검토·복원합니다. Claude in Chrome은 별도 Chrome 확장이며, Team/Enterprise의 전체 컴퓨터 사용 기능과 같지 않습니다. 로그인과 사이트·폴더 권한 승인은 항상 사람이 직접 수행합니다.

## 목적

준비된 시작본을 바탕으로 가상 성취도 CSV를 검사하고, 계산 결과를 원자료와 추적하며, 교수자가 피드백을 승인·수정·보류할 수 있는 정적 웹 앱을 만듭니다.

## 첨부할 파일

처음에는 다음 네 파일만 첨부합니다.

1. `내_작업/index.html` — 수정할 준비된 복사본
2. `데이터/성취도_정상.csv` — 실제 사람과 연결되지 않는 가상 데이터
3. `데이터/데이터사전.md` — 열과 계산 규칙
4. 현재 단계의 `단계별_프롬프트/*.txt` — 이번 작업 범위

화면 비교가 필요할 때만 `시작본/index.html`, 해당 중간 체크포인트 또는 `완성본/index.html`을 추가로 첨부합니다.

## Claude가 지켜야 할 원칙

- 필수 열은 `학습자번호,형성평가,과제,참여,출석률`이며 영문 열 이름으로 바꾸지 않습니다.
- 가상 ID는 `L-001`부터 `L-010`만 예시로 사용합니다.
- 기본 가중치는 `35/35/15/15`, 기본 기준은 `총점 70/요소 60`입니다.
- 원본 CSV를 임의로 고치지 않고 오류의 행·열·값을 설명합니다.
- ‘지원 확인 필요’를 학생 판정, 진단, 낙인, 성적 확정으로 표현하지 않습니다.
- 학생의 능력·태도·의지·원인을 추정하지 않습니다.
- 피드백은 초안이며 교수자가 `승인·수정·보류` 중 하나를 선택합니다.
- 내보내기에는 `승인` 상태인 항목만 포함합니다.
- 실제 학생정보, 로그인, 서버 저장, 외부 전송, 메일 발송, 학사시스템 변경을 추가하지 않습니다.
- 외부 CDN·라이브러리·API를 사용하지 않습니다.
- 원본 파일을 덮어쓰지 않고 단계별로 새 파일을 만듭니다.

## 작업 방식

1. 요청을 읽고 수정할 항목·유지할 항목·시험할 항목을 먼저 표로 제시합니다.
2. 사용자가 확인하기 전에는 코드를 만들지 않습니다.
3. 승인 후 현재 단계 하나만 구현합니다.
4. 완료 후 바뀐 부분, 실행 방법, 정상 시험, 오류 시험을 짧게 보고합니다.
5. 직접 실행하지 않은 기능은 ‘확인 필요’라고 표시합니다.

## 완료 보고 형식

- 새 파일 이름
- 구현한 단계
- 사용한 데이터 열과 기준값
- 직접 눌러 볼 버튼
- 정상 시험 1건
- 오류 시험 1건
- 남은 작업

## 공식 안내

- [Cowork Project에서 기존 폴더 사용](https://support.claude.com/en/articles/14116274-organize-your-tasks-with-projects-in-claude-cowork)
- [Cowork Live artifacts와 버전 기록](https://support.claude.com/en/articles/14729249-use-live-artifacts-in-claude-cowork)
- [Claude in Chrome 권한](https://support.claude.com/en/articles/12902446-claude-in-chrome-permissions-guide)
- [Team·Enterprise Cowork 관리자 설정](https://support.claude.com/en/articles/13455879-use-claude-cowork-on-team-and-enterprise-plans)
