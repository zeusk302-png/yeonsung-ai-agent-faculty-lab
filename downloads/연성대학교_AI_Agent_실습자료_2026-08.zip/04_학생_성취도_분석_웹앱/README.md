# 실습 결과물 04 · 학생 성취도 분석 및 자동 피드백 웹 앱

## 권장 실행 환경 · Claude Desktop Cowork

Claude Desktop에서 Cowork Project를 만들고 `Use an existing folder`로 이 실습 폴더를 사람이 직접 연결합니다. `CLAUDE_APP_바로시작.md`의 화면 순서를 확인한 뒤 `START_PROMPT.md`를 한 번 복사합니다. 권한 모드는 `Manually approve(수동 승인)`로 유지하며, Claude가 계획을 제시하면 사람이 승인하고 `내_작업/index.html`만 수정하게 합니다. 결과는 Live artifact 또는 앱 내부 미리보기에서 확인하고 필요하면 이전 버전을 복원합니다.

9차시 60분 핵심 실습과 25분 선택 확장을 위한 독립 실행형 패키지입니다. 폴더 전체를 복사하면 인터넷, 서버, 로그인 없이 `file://` 환경에서 실행됩니다.

## 가장 먼저 할 일

1. `00_먼저읽기.html`을 더블클릭합니다.
2. `데이터/성취도_정상.csv`가 **실제 학생과 연결되지 않는 가상 데이터**인지 확인합니다.
3. Cowork Project에서 이 실습 폴더를 연결하고 `START_PROMPT.md`를 한 번 보냅니다.
4. `PROJECT_INSTRUCTIONS.md`와 `CHECKLIST.md`를 적용하고 Claude의 계획을 승인합니다.
5. Claude 웹과 Claude Code는 대체·선택 경로입니다. Code를 이미 사용하는 참여자만 `CLAUDE.md`를 사용합니다.
6. 막히면 `중간_체크포인트`에서 다시 시작하고, 오류 원인은 `오류복구/00_오류복구_안내.html`에서 찾습니다.

## 60분 기본 경로

`내_작업/index.html → 체크포인트 01 데이터 검사 → 체크포인트 02 계산·추적 → 체크포인트 03 검토 상태 → 완성본 → 승인본 내보내기`

60분 핵심 완료선은 기준 변경, 원자료·계산식 추적, 승인·수정·보류, 승인 항목 내보내기입니다. 60~85분 확장에서는 오류 CSV 한 가지와 내 과목용 기준·문체 변경을 다룹니다.

처음부터 모든 코드를 작성하지 않습니다. 준비된 시작본과 체크포인트를 Claude에 첨부해 한 단계씩 바꾸고, 각 단계가 작동하는지 확인한 뒤 다음 단계로 이동합니다.

## 폴더 구조

- `00_먼저읽기.html` — 시간표, 준비물, 파일별 역할
- `워크북.html` — 강사와 함께 진행하는 60분 안내
- `PROJECT_INSTRUCTIONS.md` — Claude 웹 대화에 첨부하는 작업 원칙
- `CLAUDE.md` — Claude Code 선택 경로의 작업 원칙
- `TASKS.md` — 단계별 작업 목록
- `CHECKLIST.md` — 제출 전 기능·안전 점검표
- `데이터` — 정상 CSV, 오류 CSV, 데이터사전
- `단계별_프롬프트` — Claude 웹에 순서대로 붙여 넣는 요청문
- `시작본` — CSV를 읽는 최소 화면
- `내_작업` — 시작본을 복사해 둔 실제 수정 폴더
- `중간_체크포인트` — 데이터 검사, 계산·추적, 검토 상태까지 구현한 복구본
- `완성본` — 기준값·가중치 변경, 원자료·계산식 추적, 승인·수정·보류, 승인 항목 내보내기
- `오류복구` — 증상별 확인 순서와 오류 파일 실습

## 데이터 계약

- 필수 열: `학습자번호,형성평가,과제,참여,출석률`
- 가상 ID: `L-001`부터 `L-010`
- 점수 범위: 0~100
- 기본 가중치: 형성평가 35%, 과제 35%, 참여 15%, 출석률 15%
- 기본 확인 기준: 총점 70 미만 또는 어느 요소든 60 미만

‘지원 확인 필요’는 교수자가 원자료를 다시 볼 순서를 정하는 **참고 신호**입니다. 학생의 상태, 능력, 태도, 원인을 자동 판정하지 않습니다.

## 기술 범위

- 최신 Chrome, Edge, Firefox
- HTML·CSS·JavaScript만 사용
- 외부 라이브러리·네트워크 요청 없음
- 데이터는 현재 브라우저 메모리에서만 처리
- 승인된 피드백만 CSV로 내려받기
- 실제 학생자료, 자동 발송, 성적 확정, 학사시스템 변경은 실습 범위 밖

## 문제 해결과 공식 안내

- [Claude Cowork 시작하기](https://support.claude.com/en/articles/13345190-get-started-with-claude-cowork)
- [Cowork Project에서 기존 폴더 사용](https://support.claude.com/en/articles/14116274-organize-your-tasks-with-projects-in-claude-cowork)
- [Cowork Live artifacts와 버전 복원](https://support.claude.com/en/articles/14729249-use-live-artifacts-in-claude-cowork)
- [Claude in Chrome 시작하기](https://support.claude.com/en/articles/12012173-get-started-with-claude-in-chrome)
- [Team·Enterprise Cowork 관리자 설정](https://support.claude.com/en/articles/13455879-use-claude-cowork-on-team-and-enterprise-plans)
- [Claude Desktop 딥 링크](https://support.claude.com/en/articles/14729294-open-claude-desktop-with-a-link)
