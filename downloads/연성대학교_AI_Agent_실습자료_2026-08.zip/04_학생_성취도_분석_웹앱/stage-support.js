(() => {
  "use strict";

  const REQUIRED = ["학습자번호", "형성평가", "과제", "참여", "출석률"];
  const SCORE_FIELDS = REQUIRED.slice(1);
  const DEFAULT_WEIGHTS = { 형성평가: 35, 과제: 35, 참여: 15, 출석률: 15 };
  const SAMPLE = `학습자번호,형성평가,과제,참여,출석률
L-001,92,88,90,96
L-002,78,72,84,91
L-003,58,64,62,86
L-004,85,91,75,98
L-005,66,55,70,82
L-006,95,94,88,100
L-007,72,69,78,89
L-008,49,57,60,74
L-009,81,83,86,95
L-010,74,77,68,92`;

  const stage = Number(document.body.dataset.stage || 0);
  const status = document.getElementById("status");
  const output = document.getElementById("output");
  let current = [];

  function parseCSV(text) {
    const rows = [];
    let row = [], cell = "", quoted = false;
    const source = String(text).replace(/^\uFEFF/, "").replace(/\r\n?/g, "\n");
    for (let i = 0; i < source.length; i += 1) {
      const char = source[i];
      if (char === '"') {
        if (quoted && source[i + 1] === '"') { cell += '"'; i += 1; }
        else quoted = !quoted;
      } else if (char === "," && !quoted) { row.push(cell.trim()); cell = ""; }
      else if (char === "\n" && !quoted) {
        row.push(cell.trim());
        if (row.some((value) => value !== "")) rows.push(row);
        row = []; cell = "";
      } else cell += char;
    }
    row.push(cell.trim());
    if (row.some((value) => value !== "")) rows.push(row);
    if (quoted) throw new Error("따옴표가 닫히지 않은 CSV 셀이 있습니다.");
    return rows;
  }

  function escapeHtml(value) {
    return String(value).replace(/[&<>"']/g, (char) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[char]));
  }

  function validate(text) {
    const rows = parseCSV(text);
    if (rows.length < 2) throw new Error("머리글과 한 줄 이상의 데이터가 필요합니다.");
    const headers = rows[0];
    if (stage >= 1) {
      const missing = REQUIRED.filter((header) => !headers.includes(header));
      if (missing.length) throw new Error(`필수 열이 없습니다: ${missing.join(", ")}`);
      if (headers.length !== REQUIRED.length || headers.some((header, index) => header !== REQUIRED[index])) throw new Error(`머리글은 이 순서의 한글 5열만 사용합니다: ${REQUIRED.join(", ")}`);
    }
    const seen = new Set();
    const errors = [];
    const records = rows.slice(1).map((cells, index) => {
      if (stage >= 1 && cells.length !== headers.length) errors.push(`${index + 2}행의 열 수가 ${cells.length}개입니다. 머리글과 같은 ${headers.length}개여야 합니다.`);
      const record = Object.fromEntries(headers.map((header, column) => [header, cells[column] ?? ""]));
      record.__row = index + 2;
      if (stage >= 1) {
        if (!record.학습자번호) errors.push(`${record.__row}행 학습자번호가 비어 있습니다.`);
        else if (!/^L-\d{3}$/.test(record.학습자번호) || Number(record.학습자번호.slice(2)) < 1 || Number(record.학습자번호.slice(2)) > 10) errors.push(`${record.__row}행 학습자번호 '${record.학습자번호}'는 L-001~L-010 가상 ID여야 합니다.`);
        else if (seen.has(record.학습자번호)) errors.push(`${record.__row}행 학습자번호가 중복됩니다: ${record.학습자번호}`);
        else seen.add(record.학습자번호);
        SCORE_FIELDS.forEach((field) => {
          const raw = record[field];
          const value = Number(raw);
          if (raw === "" || !Number.isFinite(value) || value < 0 || value > 100) errors.push(`${record.__row}행 ${field} 값 '${raw || "빈값"}'은 0~100 숫자여야 합니다.`);
          record[field] = value;
        });
      }
      return record;
    });
    if (stage >= 1) {
      if (errors.length) throw new Error(errors.join(" / "));
      const expected = Array.from({ length: 10 }, (_, index) => `L-${String(index + 1).padStart(3, "0")}`);
      const missingIds = expected.filter((id) => !seen.has(id));
      if (records.length !== 10 || missingIds.length) throw new Error(`L-001~L-010 10행이 필요합니다. 빠진 ID: ${missingIds.join(", ") || "없음"}`);
    }
    return records;
  }

  function calculate(records, totalThreshold = 70, componentThreshold = 60) {
    return records.map((record) => {
      const total = Math.round(SCORE_FIELDS.reduce((sum, field) => sum + record[field] * DEFAULT_WEIGHTS[field] / 100, 0) * 10) / 10;
      const lowFields = SCORE_FIELDS.filter((field) => record[field] < componentThreshold);
      const reasons = [];
      if (total < totalThreshold) reasons.push(`가중총점 ${total} < ${totalThreshold}`);
      if (lowFields.length) reasons.push(`${lowFields.map((field) => `${field} ${record[field]}`).join(", ")} < ${componentThreshold}`);
      return {
        ...record,
        가중총점: total,
        확인: reasons.length ? "지원 확인 필요" : "현재 흐름 유지",
        이유: reasons.join(" · ") || "현재 기준에 해당하지 않음",
        계산식: `${record.형성평가}×0.35 + ${record.과제}×0.35 + ${record.참여}×0.15 + ${record.출석률}×0.15 = ${total}`,
        검토상태: "수정"
      };
    });
  }

  function render(records) {
    current = stage >= 2 ? calculate(records) : records;
    const columns = stage >= 2 ? [...REQUIRED, "가중총점", "확인"] : Object.keys(records[0]).filter((key) => !key.startsWith("__"));
    const rows = current.map((record, index) => `<tr>${columns.map((column) => `<td>${escapeHtml(record[column] ?? "")}</td>`).join("")}${stage >= 2 ? `<td><details><summary>근거 보기</summary><p>원자료 ${record.__row}행</p><p>${escapeHtml(record.계산식)}</p><p>${escapeHtml(record.이유)}</p></details></td>` : ""}${stage >= 3 ? `<td><label class="screen-reader" for="state-${index}">${escapeHtml(record.학습자번호)} 검토 상태</label><select id="state-${index}" data-state-index="${index}"><option>수정</option><option>승인</option><option>보류</option></select></td>` : ""}</tr>`).join("");
    const extraHeaders = `${stage >= 2 ? "<th>추적</th>" : ""}${stage >= 3 ? "<th>검토 상태</th>" : ""}`;
    const intro = stage === 0 ? "CSV 10행을 읽었습니다. 다음 단계에서 열과 점수 범위를 검사합니다." : stage === 1 ? "필수 열·가상 ID·점수 범위 검사를 통과했습니다." : stage === 2 ? "가중 총점과 원자료·계산식 추적을 표시했습니다." : "기준값과 교수자 검토 상태를 확인할 수 있습니다.";
    const criteria = stage >= 3 ? `<div class="note"><strong>기준 변경 연습</strong><div class="grid-2"><label>총점 기준<input id="stageTotal" type="number" min="0" max="100" value="70"></label><label>요소 기준<input id="stageComponent" type="number" min="0" max="100" value="60"></label></div><button id="stageApply" type="button">기준 적용</button><p id="stageCriterionStatus" class="status"></p></div>` : "";
    output.innerHTML = `${criteria}<div class="note"><strong>${intro}</strong><br>${stage >= 2 ? "‘지원 확인 필요’는 자동 판정이 아니라 교수자 확인용 참고 신호입니다." : ""}</div><div class="table-wrap"><table><thead><tr>${columns.map((column) => `<th>${escapeHtml(column)}</th>`).join("")}${extraHeaders}</tr></thead><tbody>${rows}</tbody></table></div>`;
    if (stage >= 3) {
      output.querySelectorAll("[data-state-index]").forEach((select) => select.addEventListener("change", () => { current[Number(select.dataset.stateIndex)].검토상태 = select.value; }));
      document.getElementById("stageApply").addEventListener("click", () => {
        const total = Number(document.getElementById("stageTotal").value);
        const component = Number(document.getElementById("stageComponent").value);
        if (![total, component].every((value) => Number.isFinite(value) && value >= 0 && value <= 100)) { document.getElementById("stageCriterionStatus").textContent = "기준은 0~100 숫자로 입력하세요."; return; }
        const raw = current.map((record) => Object.fromEntries([...REQUIRED, "__row"].map((key) => [key, record[key]])));
        current = calculate(raw, total, component);
        renderWithThresholds(current, total, component);
      });
    }
  }

  function renderWithThresholds(records, total, component) {
    const attention = records.filter((record) => record.확인 === "지원 확인 필요").length;
    document.getElementById("stageCriterionStatus").textContent = `총점 ${total}, 요소 ${component} 기준을 적용했습니다. 지원 확인 필요 ${attention}건입니다. 검토 상태는 수정으로 돌아갔습니다.`;
    output.querySelector("tbody").innerHTML = records.map((record, index) => `<tr>${[...REQUIRED, "가중총점", "확인"].map((column) => `<td>${escapeHtml(record[column])}</td>`).join("")}<td><details><summary>근거 보기</summary><p>원자료 ${record.__row}행</p><p>${escapeHtml(record.계산식)}</p><p>${escapeHtml(record.이유)}</p></details></td><td><select data-state-index="${index}"><option>수정</option><option>승인</option><option>보류</option></select></td></tr>`).join("");
    output.querySelectorAll("[data-state-index]").forEach((select) => select.addEventListener("change", () => { records[Number(select.dataset.stateIndex)].검토상태 = select.value; }));
  }

  function run(text) {
    try {
      const records = validate(text);
      render(records);
      status.textContent = "데이터 처리가 완료되었습니다.";
      status.className = "status success";
    } catch (error) {
      current = [];
      output.innerHTML = "";
      status.textContent = error.message;
      status.className = "status error";
    }
  }

  document.getElementById("sample").addEventListener("click", () => run(SAMPLE));
  document.getElementById("file").addEventListener("change", (event) => {
    const file = event.target.files[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = () => run(reader.result);
    reader.onerror = () => { status.textContent = "파일을 읽지 못했습니다. UTF-8 CSV인지 확인하세요."; status.className = "status error"; };
    reader.readAsText(file, "utf-8");
  });
})();
