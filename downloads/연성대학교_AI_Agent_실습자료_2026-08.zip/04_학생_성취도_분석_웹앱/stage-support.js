(() => {
  'use strict';
  const required=['학습자번호','형성평가','과제','참여','출석률'];
  const learnerIdPattern=/^[A-Za-z0-9_-]{1,40}$/;
  const sample=`학습자번호,형성평가,과제,참여,출석률\nL-001,92,88,90,96\nL-002,78,72,84,91\nL-003,58,64,62,86\nL-004,85,91,75,98\nL-005,66,55,70,82`;
  const stage=Number(document.body.dataset.stage||0); const status=document.getElementById('status'); const output=document.getElementById('output');
  const parse=text=>text.replace(/^\uFEFF/,'').trim().split(/\r?\n/).map(line=>line.split(',').map(v=>v.trim()));
  const esc=v=>String(v).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
  function run(text){
    try{
      const rows=parse(text); if(rows.length<2)throw Error('머리글과 한 줄 이상의 데이터가 필요합니다.'); const heads=rows[0];
      if(stage>=1){const missing=required.filter(h=>!heads.includes(h));if(missing.length)throw Error(`필수 열이 없습니다: ${missing.join(', ')}`);}
      const data=rows.slice(1).map((cells,i)=>Object.fromEntries(heads.map((h,j)=>[h,cells[j]??''])));
      if(stage>=1){const ids=new Set();data.forEach((r,i)=>{if(!learnerIdPattern.test(r.학습자번호))throw Error(`${i+2}행 학습자번호는 영문자, 숫자, 하이픈(-), 밑줄(_)만 사용해 1~40자로 입력해야 합니다. 실제 식별정보 대신 L-001 같은 가상 번호를 사용해 주세요.`);if(ids.has(r.학습자번호))throw Error(`${i+2}행 학습자번호가 중복됩니다: ${r.학습자번호}`);ids.add(r.학습자번호);required.slice(1).forEach(key=>{const n=Number(r[key]);if(r[key]===''||!Number.isFinite(n)||n<0||n>100)throw Error(`${i+2}행 ${key} 값은 0~100의 숫자여야 합니다.`);r[key]=n;});});}
      if(stage>=2)data.forEach(r=>{r.가중평균=Math.round((r.형성평가*.35+r.과제*.35+r.참여*.15+r.출석률*.15)*10)/10;r.확인=(r.가중평균<70||required.slice(1).some(k=>r[k]<60))?'지원 확인 필요':'현재 흐름 유지';});
      const displayHeads=stage>=2?[...required,'가중평균','확인']:heads;
      output.innerHTML=`<div class="note"><strong>${data.length}행을 읽었습니다.</strong> ${stage===0?'다음 단계에서 열 이름과 점수 범위를 확인합니다.':stage===1?'필수 열과 점수 범위 검사를 통과했습니다.':'가중 평균과 참고 신호를 계산했습니다.'}</div><div class="table-wrap"><table><thead><tr>${displayHeads.map(h=>`<th>${esc(h)}</th>`).join('')}</tr></thead><tbody>${data.map(r=>`<tr>${displayHeads.map(h=>`<td>${esc(r[h]??'')}</td>`).join('')}</tr>`).join('')}</tbody></table></div>`;
      status.textContent='데이터 처리가 완료되었습니다.';status.className='status success';
    }catch(e){output.innerHTML='';status.textContent=e.message;status.className='status error';}
  }
  document.getElementById('sample').addEventListener('click',()=>run(sample));
  document.getElementById('file').addEventListener('change',e=>{const f=e.target.files[0];if(!f)return;const r=new FileReader();r.onload=()=>run(r.result);r.onerror=()=>{status.textContent='파일을 읽지 못했습니다.';status.className='status error';};r.readAsText(f,'utf-8');});
})();
