# Day 2 실습 4 · 교수 업무 안전 대시보드

## 권장 실행 환경 · Claude Desktop Cowork

Claude Desktop에서 Cowork Project를 만들고 `Use an existing folder`로 이 실습 폴더를 사람이 직접 연결합니다. `CLAUDE_APP_바로시작.md`의 화면 순서를 확인한 뒤 `START_PROMPT.md`를 한 번 복사합니다. 권한 모드는 `Manually approve(수동 승인)`로 유지하며, Claude가 계획을 제시하면 사람이 승인하고 `내_작업/index.html`만 수정하게 합니다. 결과는 Live artifact 또는 앱 내부 미리보기에서 확인하고 필요하면 이전 버전을 복원합니다.

10차시의 `출결·성적 현황 + 피드백 자동생성 + 행정 To-Do + 동료 공유`를 초보 교수자가 가상 데이터로 안전하게 연습하는 독립 정적 패키지입니다.

## 시작

1. `00_먼저읽기.html`을 더블클릭합니다.
2. Cowork Project에서 이 실습 폴더를 연결하고 `START_PROMPT.md`를 한 번 보냅니다.
3. `PROJECT_INSTRUCTIONS.md`와 `CHECKLIST.md`를 적용하고 Claude의 계획을 승인합니다.
4. Claude 웹과 Claude Code는 대체·선택 경로입니다. 필요할 때만 `CLAUDE.md`를 읽습니다.
5. `내_작업 → 중간본 → 완성본 → 오류복구` 순서로 확인합니다.

## 안전 범위

- 실제 학생과 연결되지 않는 `L-001~L-010`, `T-001~T-005`만 사용합니다.
- 모든 계산·초안·승인·완료 처리는 현재 브라우저 안의 실습 상태입니다.
- 외부 전송, 메일 발송, 학사시스템 변경, 실제 파일 삭제 기능은 없습니다.
- 활동 기록은 이 브라우저의 로컬 저장소에만 남으며 운영용 감사 로그가 아닙니다.
- 동료 공유는 개인을 제외한 로컬 요약을 복사하는 단계까지만 수행합니다.

## 구성

- `00_먼저읽기.html`: 수업 시작 화면
- `PROJECT_INSTRUCTIONS.md`: Claude 웹 프로젝트 지침
- `CLAUDE.md`: Claude Code 선택 활동 지침
- `TASKS.md`: 60분 핵심 완료선 + 25분 반복·개인화 순서
- `CHECKLIST.md`: 완료 기준·평가표·중단 조건
- `01_단계별_프롬프트.html`: 단계별 복사 프롬프트
- `내_작업`: 시작본을 미리 복사해 둔 실제 수정 폴더
- `데이터`: 정상·오류 가상 CSV
- `시작본`: 입력·검사
- `중간본`: 현황·등급분포·추적 가능한 피드백 초안
- `완성본`: 승인·영향범위·To-Do 확인/실행취소·활동기록·로컬 공유 요약
- `오류복구`: 실패 원인·재시도·복구 실습

## 문제 해결과 공식 안내

- [Claude Cowork 시작하기](https://support.claude.com/en/articles/13345190-get-started-with-claude-cowork)
- [Cowork Project에서 기존 폴더 사용](https://support.claude.com/en/articles/14116274-organize-your-tasks-with-projects-in-claude-cowork)
- [Cowork Live artifacts와 버전 복원](https://support.claude.com/en/articles/14729249-use-live-artifacts-in-claude-cowork)
- [Claude in Chrome 시작하기](https://support.claude.com/en/articles/12012173-get-started-with-claude-in-chrome)
- [Team·Enterprise Cowork 관리자 설정](https://support.claude.com/en/articles/13455879-use-claude-cowork-on-team-and-enterprise-plans)
- [Claude Desktop 딥 링크](https://support.claude.com/en/articles/14729294-open-claude-desktop-with-a-link)
