(() => {
  "use strict";

  const learningSample = `학습자번호,출석률,과제제출률,성적
L-001,96,100,92
L-002,91,80,78
L-003,86,60,64
L-004,98,100,89
L-005,82,60,68
L-006,100,100,95
L-007,89,80,73
L-008,74,40,57
L-009,95,100,84
L-010,92,80,76`;
  const taskSample = `업무번호,업무명,마감일,완료여부,담당
T-001,평가기준 공개 여부 확인,2026-08-20,예,교수자
T-002,형성평가 결과 검토,2026-08-22,아니오,교수자
T-003,학습 지원 안내 초안 검토,2026-08-24,아니오,교수자
T-004,출석 이의신청 확인,2026-08-26,아니오,교수자
T-005,수업자료 접근성 점검,2026-08-28,아니오,교수자`;
  const badLearningMissing = `학습자번호,출석률,성적
L-001,96,92
L-002,91,78`;
  const badLearningRange = `학습자번호,출석률,과제제출률,성적
L-001,96,100,92
L-002,103,80,78
L-003,86,-1,64`;
  const badTaskDate = `업무번호,업무명,마감일,완료여부,담당
T-001,평가기준 공개 여부 확인,2026-02-30,예,교수자
T-002,형성평가 결과 검토,2026-08-22,아니오,교수자`;
  const badTaskRequired = `업무번호,업무명,마감일,완료여부,담당
T-001,,2026-08-20,예,교수자
T-002,형성평가 결과 검토,2026-08-22,완료,교수자`;

  const learningRequired = ["학습자번호", "출석률", "과제제출률", "성적"];
  const taskRequired = ["업무번호", "업무명", "마감일", "완료여부", "담당"];
  const allowedLearners = new Set(Array.from({ length: 10 }, (_, index) => `L-${String(index + 1).padStart(3, "0")}`));
  const allowedTasks = new Set(Array.from({ length: 5 }, (_, index) => `T-${String(index + 1).padStart(3, "0")}`));
  const LOG_KEY = "ysu-day2-practice4-activity-v1";
  const stage = document.body.dataset.stage || "complete";
  const $ = (id) => document.getElementById(id);
  const exists = (id) => Boolean($(id));

  const state = {
    learners: [],
    tasks: [],
    logs: [],
    failed: false,
    lastFailure: null,
    pendingTask: null,
    lastUndo: null,
    feedbackApproved: false,
    feedbackFingerprint: "",
  };

  function escapeHtml(value) {
    return String(value).replace(/[&<>"']/g, (character) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[character]));
  }

  function parseCSV(text) {
    const rows = [];
    let row = [];
    let cell = "";
    let quoted = false;
    const source = String(text).replace(/^\uFEFF/, "").replace(/\r\n?/g, "\n");
    for (let index = 0; index < source.length; index += 1) {
      const character = source[index];
      if (character === '"') {
        if (quoted && source[index + 1] === '"') { cell += '"'; index += 1; }
        else quoted = !quoted;
      } else if (character === "," && !quoted) {
        row.push(cell.trim()); cell = "";
      } else if (character === "\n" && !quoted) {
        row.push(cell.trim());
        if (row.some((value) => value !== "")) rows.push(row);
        row = []; cell = "";
      } else cell += character;
    }
    row.push(cell.trim());
    if (row.some((value) => value !== "")) rows.push(row);
    if (quoted) throw new Error("따옴표가 닫히지 않은 CSV입니다.");
    return rows;
  }

  function recordsFromCSV(text, required) {
    const rows = parseCSV(text);
    if (rows.length < 2) throw new Error("머리글과 한 줄 이상의 데이터가 필요합니다.");
    const headers = rows[0];
    const missing = required.filter((name) => !headers.includes(name));
    if (missing.length) throw new Error(`필수 열 누락: ${missing.join(", ")}`);
    const duplicateHeaders = headers.filter((name, index) => headers.indexOf(name) !== index);
    if (duplicateHeaders.length) throw new Error(`중복 머리글: ${[...new Set(duplicateHeaders)].join(", ")}`);
    const unexpected = headers.filter((name) => !required.includes(name));
    if (unexpected.length) throw new Error(`허용하지 않는 열: ${unexpected.join(", ")}. 이름·이메일 등 실제 개인정보 열을 추가하지 마세요.`);
    return rows.slice(1).map((cells, index) => {
      if (cells.length !== headers.length) throw new Error(`${index + 2}행의 열 개수는 머리글 ${headers.length}개와 같아야 합니다.`);
      return Object.fromEntries(headers.map((header, cellIndex) => [header, cells[cellIndex] ?? ""]));
    });
  }

  function validDate(value) {
    if (!/^\d{4}-\d{2}-\d{2}$/.test(value)) return false;
    const [year, month, day] = value.split("-").map(Number);
    const date = new Date(Date.UTC(year, month - 1, day));
    return date.getUTCFullYear() === year && date.getUTCMonth() === month - 1 && date.getUTCDate() === day;
  }

  function validateLearning(text) {
    const seen = new Set();
    return recordsFromCSV(text, learningRequired).map((record, index) => {
      const rowNumber = index + 2;
      const id = record.학습자번호;
      if (!allowedLearners.has(id)) throw new Error(`${rowNumber}행 학습자번호는 이 실습의 L-001~L-010만 사용할 수 있습니다.`);
      if (seen.has(id)) throw new Error(`${rowNumber}행 학습자번호가 중복됩니다: ${id}`);
      seen.add(id);
      ["출석률", "과제제출률", "성적"].forEach((key) => {
        const number = Number(record[key]);
        if (record[key] === "" || !Number.isFinite(number) || number < 0 || number > 100) throw new Error(`${rowNumber}행 ${key} 값은 0~100의 숫자여야 합니다: ${record[key] || "빈 값"}`);
        record[key] = number;
      });
      return record;
    });
  }

  function validateTasks(text) {
    const seen = new Set();
    return recordsFromCSV(text, taskRequired).map((record, index) => {
      const rowNumber = index + 2;
      const id = record.업무번호;
      if (!allowedTasks.has(id)) throw new Error(`${rowNumber}행 업무번호는 이 실습의 T-001~T-005만 사용할 수 있습니다.`);
      if (seen.has(id)) throw new Error(`${rowNumber}행 업무번호가 중복됩니다: ${id}`);
      seen.add(id);
      if (!record.업무명) throw new Error(`${rowNumber}행 업무명이 비어 있습니다.`);
      if (!validDate(record.마감일)) throw new Error(`${rowNumber}행 마감일은 실제 존재하는 YYYY-MM-DD 날짜여야 합니다: ${record.마감일 || "빈 값"}`);
      if (!["예", "아니오"].includes(record.완료여부)) throw new Error(`${rowNumber}행 완료여부는 예 또는 아니오여야 합니다: ${record.완료여부 || "빈 값"}`);
      if (record.담당 !== "교수자") throw new Error(`${rowNumber}행 담당은 개인정보가 아닌 역할명 ‘교수자’로 입력합니다.`);
      return { id, name: record.업무명, date: record.마감일, done: record.완료여부 === "예", owner: record.담당 };
    });
  }

  function setStatus(id, message, type = "") {
    if (!exists(id)) return;
    $(id).textContent = message;
    $(id).className = `status ${type}`.trim();
  }

  function safeLogsFromStorage() {
    try {
      const value = JSON.parse(localStorage.getItem(LOG_KEY) || "[]");
      return Array.isArray(value) ? value.slice(0, 100) : [];
    } catch { return []; }
  }

  function saveLogs() {
    try { localStorage.setItem(LOG_KEY, JSON.stringify(state.logs.slice(0, 100))); }
    catch { setStatus("logStatus", "브라우저가 로컬 활동기록 저장을 허용하지 않았습니다. 현재 화면에서만 확인합니다.", "error"); }
  }

  function addLog(action, detail = {}) {
    const entry = {
      time: new Date().toISOString(),
      stage,
      action,
      target: detail.target || "실습 화면",
      before: detail.before ?? "—",
      after: detail.after ?? "—",
      impact: detail.impact || "가상 화면 1건 이하",
      externalImpact: "0건",
      result: detail.result || "완료",
    };
    state.logs.unshift(entry);
    state.logs = state.logs.slice(0, 100);
    saveLogs();
    renderLog();
  }

  function renderLog() {
    if (!exists("activityLog")) return;
    const list = $("activityLog");
    list.replaceChildren();
    if (!state.logs.length) {
      const item = document.createElement("li");
      item.textContent = "아직 실습 활동기록이 없습니다.";
      list.appendChild(item);
      return;
    }
    state.logs.slice(0, 20).forEach((entry) => {
      const item = document.createElement("li");
      const time = new Date(entry.time).toLocaleString("ko-KR");
      item.textContent = `${time} · ${entry.action} · 대상 ${entry.target} · ${entry.before} → ${entry.after} · 외부 영향 ${entry.externalImpact} · ${entry.result}`;
      list.appendChild(item);
    });
  }

  function showFailure(kind, error) {
    state.failed = true;
    state.lastFailure = { kind, message: error.message };
    setStatus(kind === "learning" ? "learningStatus" : "taskStatus", error.message, "error");
    if (exists("failurePanel")) {
      $("failurePanel").classList.remove("hidden");
      if (exists("failureTitle")) $("failureTitle").textContent = `${kind === "learning" ? "학습 현황" : "업무 일정"} 처리를 중단했습니다.`;
      if (exists("failureDetail")) $("failureDetail").textContent = `${error.message} 오류가 있는 동안 계산·Draft·Write를 진행하지 않습니다.`;
    }
    addLog("입력 오류로 중단", { target: kind, after: error.message, impact: "계산·Draft·Write 0건", result: "중단" });
    updateDisabledState();
  }

  function clearFailureIfReady() {
    if (!state.learners.length || !state.tasks.length) return;
    state.failed = false;
    state.lastFailure = null;
    if (exists("failurePanel")) $("failurePanel").classList.add("hidden");
    updateDisabledState();
  }

  function loadLearning(text, sourceLabel = "가상 학습 현황", recordActivity = true) {
    try {
      state.learners = validateLearning(text);
      setStatus("learningStatus", `${state.learners.length}행을 검사했습니다. 허용된 가상 ID와 값 범위를 통과했습니다.`, "success");
      if (recordActivity) addLog("READ 학습 현황 검사", { target: sourceLabel, after: `${state.learners.length}행 통과`, impact: "가상 데이터 읽기" });
      clearFailureIfReady();
      renderAll();
      return true;
    } catch (error) {
      state.learners = [];
      showFailure("learning", error);
      renderAll();
      return false;
    }
  }

  function loadTasks(text, sourceLabel = "가상 업무 일정", recordActivity = true) {
    try {
      state.tasks = validateTasks(text);
      setStatus("taskStatus", `${state.tasks.length}행을 검사했습니다. 허용된 가상 ID·날짜·상태를 통과했습니다.`, "success");
      if (recordActivity) addLog("READ 업무 일정 검사", { target: sourceLabel, after: `${state.tasks.length}행 통과`, impact: "가상 데이터 읽기" });
      clearFailureIfReady();
      renderAll();
      return true;
    } catch (error) {
      state.tasks = [];
      showFailure("tasks", error);
      renderAll();
      return false;
    }
  }

  function loadSamples(logRecovery = true) {
    const learningOk = loadLearning(learningSample, "내장 L-001~L-010", logRecovery);
    const tasksOk = loadTasks(taskSample, "내장 T-001~T-005", logRecovery);
    if (learningOk && tasksOk) {
      clearFailureIfReady();
      if (logRecovery) addLog("내장 가상 자료로 복구", { target: "두 CSV", after: "정상 상태", impact: "현재 브라우저 데이터" });
      setStatus("recoveryStatus", "정상 가상 자료를 다시 불러와 계산·Draft·Write를 재개할 수 있습니다.", "success");
    }
  }

  function readFile(input, handler, statusId) {
    const file = input.files?.[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = () => handler(reader.result, file.name);
    reader.onerror = () => showFailure(statusId === "learningStatus" ? "learning" : "tasks", new Error("파일을 읽지 못했습니다. 다시 선택하거나 내장 가상 자료로 복구하세요."));
    reader.readAsText(file, "utf-8");
  }

  function average(key) {
    return state.learners.length ? (state.learners.reduce((sum, learner) => sum + learner[key], 0) / state.learners.length).toFixed(1) : "—";
  }

  function gradeFor(score) {
    if (score >= 90) return "A";
    if (score >= 80) return "B";
    if (score >= 70) return "C";
    if (score >= 60) return "D";
    return "F";
  }

  function reasonsFor(learner) {
    const reasons = [];
    if (learner.출석률 < 80) reasons.push(`출석률 ${learner.출석률}% < 80%`);
    if (learner.과제제출률 < 60) reasons.push(`과제제출률 ${learner.과제제출률}% < 60%`);
    if (learner.성적 < 70) reasons.push(`성적 ${learner.성적}점 < 70점`);
    return reasons;
  }

  function gradeCounts() {
    const result = { A: 0, B: 0, C: 0, D: 0, F: 0 };
    state.learners.forEach((learner) => { result[gradeFor(learner.성적)] += 1; });
    return result;
  }

  function renderMetrics() {
    const values = {
      learnerCount: state.learners.length || "—",
      attendanceAvg: average("출석률"),
      submissionAvg: average("과제제출률"),
      gradeAvg: average("성적"),
      reviewCount: state.learners.length ? state.learners.filter((learner) => reasonsFor(learner).length).length : "—",
    };
    Object.entries(values).forEach(([id, value]) => { if (exists(id)) $(id).textContent = value; });
  }

  function renderGradeDistribution() {
    if (!exists("gradeChart")) return;
    const chart = $("gradeChart");
    chart.replaceChildren();
    if (!state.learners.length) {
      chart.textContent = "학습 현황을 불러오면 등급분포가 표시됩니다.";
      return;
    }
    const counts = gradeCounts();
    const max = Math.max(1, ...Object.values(counts));
    Object.entries(counts).forEach(([grade, count]) => {
      const row = document.createElement("div"); row.className = "bar-row";
      const label = document.createElement("strong"); label.textContent = `${grade} 등급`;
      const bar = document.createElement("div"); bar.className = "bar";
      const fill = document.createElement("span"); fill.style.width = `${(count / max) * 100}%`; fill.setAttribute("aria-label", `${grade} 등급 ${count}명`); bar.appendChild(fill);
      const value = document.createElement("span"); value.textContent = `${count}명`;
      row.append(label, bar, value); chart.appendChild(row);
    });
  }

  function renderLearnerTable() {
    if (!exists("learnerTable")) return;
    const container = $("learnerTable");
    if (!state.learners.length) { container.innerHTML = '<div class="notice">검사를 통과한 학습 현황이 없습니다.</div>'; return; }
    if (stage === "start") {
      const rows = state.learners.map((learner) => `<tr><td>${learner.학습자번호}</td><td>${learner.출석률}%</td><td>${learner.과제제출률}%</td><td>${learner.성적}</td><td><span class="pill read">검사 통과</span></td></tr>`).join("");
      container.innerHTML = `<table><caption>검사를 통과한 가상 학습 현황</caption><thead><tr><th>원본 행</th><th>출석률</th><th>제출률</th><th>성적</th><th>READ 상태</th></tr></thead><tbody>${rows}</tbody></table>`;
      return;
    }
    const rows = state.learners.map((learner) => {
      const reasons = reasonsFor(learner);
      return `<tr><td>${learner.학습자번호}</td><td>${learner.출석률}%</td><td>${learner.과제제출률}%</td><td>${learner.성적}</td><td>${gradeFor(learner.성적)}</td><td><span class="pill ${reasons.length ? "attention" : ""}">${reasons.length ? "지원 확인 필요" : "현재 기준 해당 없음"}</span><br><span class="small">${reasons.length ? escapeHtml(reasons.join(" · ")) : "원본 행에서 추가 확인 사항 없음"}</span></td></tr>`;
    }).join("");
    container.innerHTML = `<table><caption>가상 학습 현황과 표시 이유</caption><thead><tr><th>원본 행</th><th>출석률</th><th>제출률</th><th>성적</th><th>등급</th><th>적용 기준·표시 이유</th></tr></thead><tbody>${rows}</tbody></table>`;
  }

  function feedbackFor(learner) {
    const reasons = reasonsFor(learner);
    const observed = `원본 행 ${learner.학습자번호}: 출석률 ${learner.출석률}%, 과제제출률 ${learner.과제제출률}%, 성적 ${learner.성적}점(${gradeFor(learner.성적)} 등급)`;
    const signal = reasons.length ? `가상 확인 기준에 해당한 항목은 ${reasons.join(", ")}입니다.` : "현재 가상 확인 기준에 해당하는 항목은 없습니다.";
    const action = reasons.length ? "원자료와 수업 맥락을 다시 확인한 뒤, 다음 주에 실행할 작은 학습 행동 한 가지를 학생과 함께 정해 보세요." : "현재 학습 흐름을 유지하며 다음 과제에서 근거를 한 단계 더 구체화하도록 안내해 보세요.";
    return `[DRAFT · 자동 판정 아님]\n${observed}\n${signal}\n${action}\n확인 질문: 결측·평가 난이도·학습 기회·정당한 편의 등 화면에 없는 맥락은 무엇인가요?`;
  }

  function simpleFingerprint(text) {
    let hash = 2166136261;
    for (let index = 0; index < text.length; index += 1) { hash ^= text.charCodeAt(index); hash = Math.imul(hash, 16777619); }
    return `v-${(hash >>> 0).toString(16).padStart(8, "0")}`;
  }

  function invalidateFeedback(reason = "초안이 바뀌어 이전 승인을 무효화했습니다.") {
    if (!state.feedbackApproved && !state.feedbackFingerprint) return;
    state.feedbackApproved = false;
    state.feedbackFingerprint = "";
    if (exists("copyFeedback")) $("copyFeedback").disabled = true;
    if (exists("feedbackApprovalState")) $("feedbackApprovalState").textContent = "승인 전 DRAFT";
    setStatus("feedbackStatus", reason, "error");
    addLog("DRAFT 승인 무효화", { target: exists("learnerSelect") ? $("learnerSelect").value : "가상 피드백", after: "재검토 필요", impact: "피드백 초안 1건", result: "중단" });
  }

  function selectLearner() {
    if (!exists("learnerSelect") || !exists("feedbackText") || !state.learners.length) return;
    const learner = state.learners.find((item) => item.학습자번호 === $("learnerSelect").value) || state.learners[0];
    state.feedbackApproved = false;
    state.feedbackFingerprint = "";
    $("feedbackText").value = feedbackFor(learner);
    $("feedbackText").disabled = false;
    if (exists("copyFeedback")) $("copyFeedback").disabled = true;
    if (exists("feedbackApprovalState")) $("feedbackApprovalState").textContent = "승인 전 DRAFT";
    if (exists("feedbackSource")) $("feedbackSource").textContent = `${learner.학습자번호} · 출석 ${learner.출석률}% · 제출 ${learner.과제제출률}% · 성적 ${learner.성적}점 · 표시 이유: ${reasonsFor(learner).join(" / ") || "현재 기준 해당 없음"}`;
    setStatus("feedbackStatus", "원본 행과 기준을 대조하고 필요한 맥락을 보완하세요.");
  }

  function renderFeedback() {
    if (!exists("learnerSelect")) return;
    const select = $("learnerSelect");
    if (!state.learners.length) {
      select.innerHTML = '<option value="">검사를 통과한 데이터가 없습니다</option>';
      select.disabled = true;
      if (exists("feedbackText")) { $("feedbackText").value = ""; $("feedbackText").disabled = true; }
      return;
    }
    const previous = select.value;
    select.innerHTML = state.learners.map((learner) => `<option value="${learner.학습자번호}">${learner.학습자번호}</option>`).join("");
    select.value = state.learners.some((learner) => learner.학습자번호 === previous) ? previous : state.learners[0].학습자번호;
    select.disabled = false;
    selectLearner();
  }

  function renderTasks() {
    if (!exists("taskList")) return;
    const list = $("taskList");
    list.replaceChildren();
    if (!state.tasks.length) { const item = document.createElement("li"); item.textContent = "검사를 통과한 가상 업무 일정이 없습니다."; list.appendChild(item); return; }
    state.tasks.slice().sort((a, b) => a.date.localeCompare(b.date)).forEach((task) => {
      const item = document.createElement("li");
      const description = document.createElement("div");
      description.className = task.done ? "done" : "";
      const title = document.createElement("strong"); title.textContent = task.name;
      const detail = document.createElement("div"); detail.className = "small"; detail.textContent = `${task.id} · ${task.date} · 담당 역할 ${task.owner} · ${task.done ? "완료" : "미완료"}`;
      description.append(title, detail);
      const statePill = document.createElement("span"); statePill.className = `pill ${task.done ? "" : "attention"}`; statePill.textContent = task.done ? "완료" : "미완료";
      if (stage === "complete") {
        const button = document.createElement("button"); button.type = "button"; button.className = "secondary"; button.dataset.taskReview = task.id; button.textContent = task.done ? "미완료 변경 검토" : "완료 변경 검토"; button.disabled = state.failed;
        item.append(description, statePill, button);
      } else {
        const readOnly = document.createElement("span"); readOnly.className = "pill read"; readOnly.textContent = "READ 전용";
        item.append(description, statePill, readOnly);
      }
      list.appendChild(item);
    });
  }

  function renderPendingTask() {
    if (!exists("taskApproval")) return;
    const panel = $("taskApproval");
    if (!state.pendingTask) { panel.classList.add("hidden"); return; }
    panel.classList.remove("hidden");
    const pending = state.pendingTask;
    const values = {
      pendingTarget: `${pending.id} · ${pending.name}`,
      pendingChange: `${pending.before ? "완료" : "미완료"} → ${pending.after ? "완료" : "미완료"}`,
      pendingImpact: "현재 브라우저의 가상 To-Do 1건",
      pendingExternal: "외부 시스템·메일·실제 파일 0건",
      pendingUndo: "최근 변경 1건 실행 취소 가능",
    };
    Object.entries(values).forEach(([id, value]) => { if (exists(id)) $(id).textContent = value; });
  }

  function requestTaskChange(id) {
    const task = state.tasks.find((item) => item.id === id);
    if (!task || state.failed) return;
    state.pendingTask = { id: task.id, name: task.name, before: task.done, after: !task.done };
    renderPendingTask();
    updateDisabledState();
    setStatus("taskActionStatus", "아직 상태를 바꾸지 않았습니다. 영향범위를 읽고 승인 또는 취소하세요.");
  }

  function approveTaskChange() {
    const pending = state.pendingTask;
    if (!pending || state.failed) return;
    const task = state.tasks.find((item) => item.id === pending.id);
    if (!task) return;
    task.done = pending.after;
    state.lastUndo = { id: pending.id, before: pending.before, after: pending.after, name: pending.name };
    addLog("WRITE To-Do 상태 승인", { target: pending.id, before: pending.before ? "완료" : "미완료", after: pending.after ? "완료" : "미완료", impact: "현재 브라우저 가상 To-Do 1건" });
    state.pendingTask = null;
    renderTasks(); renderPendingTask(); renderShare();
    if (exists("undoTask")) $("undoTask").disabled = false;
    setStatus("taskActionStatus", "승인한 가상 To-Do 1건의 화면 상태만 변경했습니다. 외부 영향은 0건입니다.", "success");
  }

  function undoTaskChange() {
    if (!state.lastUndo) return;
    const undo = state.lastUndo;
    const task = state.tasks.find((item) => item.id === undo.id);
    if (!task) return;
    task.done = undo.before;
    addLog("WRITE 최근 변경 실행 취소", { target: undo.id, before: undo.after ? "완료" : "미완료", after: undo.before ? "완료" : "미완료", impact: "현재 브라우저 가상 To-Do 1건" });
    state.lastUndo = null;
    if (exists("undoTask")) $("undoTask").disabled = true;
    renderTasks(); renderShare();
    setStatus("taskActionStatus", "최근 상태 변경을 원래 값으로 되돌렸습니다.", "success");
  }

  function shareSummary() {
    if (!state.learners.length || !state.tasks.length) return "정상 가상 자료를 불러오면 개인 ID를 제외한 집계 요약이 만들어집니다.";
    const grades = gradeCounts();
    const review = state.learners.filter((learner) => reasonsFor(learner).length).length;
    const openTasks = state.tasks.filter((task) => !task.done).length;
    return `교수 업무 대시보드 동료 검토용 요약\n- 자료 범위: 실제 사람과 연결되지 않는 교육용 가상 자료\n- 가상 학습자 수: ${state.learners.length}명\n- 평균: 출석률 ${average("출석률")}% · 과제제출률 ${average("과제제출률")}% · 성적 ${average("성적")}점\n- 등급분포: A ${grades.A} · B ${grades.B} · C ${grades.C} · D ${grades.D} · F ${grades.F}\n- 지원 확인 참고 신호: ${review}건\n- 미완료 가상 To-Do: ${openTasks}건\n- 가상 기준: 출석 80% 미만 · 제출 60% 미만 · 성적 70점 미만 / 등급 A90·B80·C70·D60·F\n- 주의: 자동 판정·성적 확정이 아니며 교수자가 원자료와 맥락을 확인합니다.\n- 연결 상태: 외부 시스템·메일·공개 링크 없음`;
  }

  function renderShare() {
    if (exists("shareText")) $("shareText").textContent = shareSummary();
  }

  async function copyText(text, fallbackElement) {
    try { await navigator.clipboard.writeText(text); return true; }
    catch {
      if (!fallbackElement) return false;
      if ("select" in fallbackElement) { fallbackElement.focus(); fallbackElement.select(); }
      else { const range = document.createRange(); range.selectNodeContents(fallbackElement); const selection = getSelection(); selection.removeAllRanges(); selection.addRange(range); }
      try { return document.execCommand("copy") === true; }
      catch { return false; }
    }
  }

  function updateDisabledState() {
    if (exists("approveFeedback")) $("approveFeedback").disabled = state.failed || !state.learners.length;
    if (exists("approveTaskChange")) $("approveTaskChange").disabled = state.failed || !state.pendingTask;
    if (exists("copyFeedback")) $("copyFeedback").disabled = state.failed || !state.feedbackApproved;
    if (exists("copyShare")) $("copyShare").disabled = state.failed || !state.learners.length || !state.tasks.length;
    if (exists("feedbackText")) $("feedbackText").disabled = state.failed || !state.learners.length;
    if (exists("learnerSelect")) $("learnerSelect").disabled = state.failed || !state.learners.length;
  }

  function renderAll({ preserveFeedback = false } = {}) {
    renderMetrics(); renderGradeDistribution(); renderLearnerTable(); renderTasks(); renderShare(); renderPendingTask();
    if (!preserveFeedback) renderFeedback();
    renderLog(); updateDisabledState();
  }

  function downloadJson() {
    const payload = { notice: "교육용 가상 활동기록이며 운영 감사 로그가 아닙니다.", exportedAt: new Date().toISOString(), entries: state.logs };
    const blob = new Blob([JSON.stringify(payload, null, 2)], { type: "application/json;charset=utf-8" });
    const link = document.createElement("a");
    link.href = URL.createObjectURL(blob); link.download = "가상_활동기록.json"; link.click();
    setTimeout(() => URL.revokeObjectURL(link.href), 1000);
    setStatus("logStatus", "가상 활동기록 JSON을 내려받았습니다. 실제 개인정보는 기록하지 않습니다.", "success");
  }

  function bindEvents() {
    if (exists("sampleBtn")) $("sampleBtn").addEventListener("click", () => loadSamples(true));
    if (exists("retryBtn")) $("retryBtn").addEventListener("click", () => loadSamples(true));
    if (exists("learningFile")) $("learningFile").addEventListener("change", () => readFile($("learningFile"), loadLearning, "learningStatus"));
    if (exists("taskFile")) $("taskFile").addEventListener("change", () => readFile($("taskFile"), loadTasks, "taskStatus"));
    if (exists("learnerSelect")) $("learnerSelect").addEventListener("change", selectLearner);
    if (exists("feedbackText")) $("feedbackText").addEventListener("input", () => invalidateFeedback());
    if (exists("approveFeedback")) $("approveFeedback").addEventListener("click", () => {
      if (state.failed || !$("feedbackText").value.trim()) return;
      const target = $("learnerSelect").value;
      state.feedbackFingerprint = simpleFingerprint($("feedbackText").value);
      state.feedbackApproved = true;
      $("copyFeedback").disabled = false;
      if (exists("feedbackApprovalState")) $("feedbackApprovalState").textContent = `교수자 승인 · ${state.feedbackFingerprint}`;
      setStatus("feedbackStatus", "현재 문구 버전을 승인했습니다. 문구를 수정하면 승인은 자동 해제됩니다.", "success");
      addLog("DRAFT 피드백 승인", { target, after: state.feedbackFingerprint, impact: "가상 피드백 초안 1건" });
    });
    if (exists("copyFeedback")) $("copyFeedback").addEventListener("click", async () => {
      const current = simpleFingerprint($("feedbackText").value);
      if (!state.feedbackApproved || current !== state.feedbackFingerprint) { invalidateFeedback("승인한 버전과 현재 문구가 달라 복사를 중단했습니다."); return; }
      const copied = await copyText($("feedbackText").value, $("feedbackText"));
      setStatus("feedbackStatus", copied ? "승인한 피드백 초안을 복사했습니다. 외부 전송은 하지 않았습니다." : "자동 복사에 실패했습니다. 선택된 문구를 Ctrl+C로 직접 복사하세요.", copied ? "success" : "error");
      if (copied) addLog("승인한 DRAFT 로컬 복사", { target: $("learnerSelect").value, after: state.feedbackFingerprint, impact: "클립보드 1건" });
    });
    document.addEventListener("click", (event) => {
      const taskButton = event.target.closest("[data-task-review]");
      if (taskButton) requestTaskChange(taskButton.dataset.taskReview);
    });
    if (exists("approveTaskChange")) $("approveTaskChange").addEventListener("click", approveTaskChange);
    if (exists("cancelTaskChange")) $("cancelTaskChange").addEventListener("click", () => { state.pendingTask = null; renderPendingTask(); updateDisabledState(); setStatus("taskActionStatus", "상태 변경을 취소했습니다. 실제 변경은 0건입니다."); });
    if (exists("undoTask")) $("undoTask").addEventListener("click", undoTaskChange);
    if (exists("copyShare")) $("copyShare").addEventListener("click", async () => {
      const copied = await copyText(shareSummary(), $("shareText"));
      setStatus("shareStatus", copied ? "개인 ID를 제외한 집계 요약을 복사했습니다." : "자동 복사에 실패했습니다. 선택된 요약을 Ctrl+C로 복사하세요.", copied ? "success" : "error");
      if (copied) addLog("동료 검토용 집계 요약 복사", { target: "비식별 집계", impact: "클립보드 1건" });
    });
    if (exists("exportLog")) $("exportLog").addEventListener("click", downloadJson);
    if (exists("clearLog")) $("clearLog").addEventListener("click", () => { $("clearLog").classList.add("hidden"); if (exists("confirmClearLog")) $("confirmClearLog").classList.remove("hidden"); if (exists("cancelClearLog")) $("cancelClearLog").classList.remove("hidden"); setStatus("logStatus", "이 브라우저의 가상 활동기록만 지울지 확인하세요."); });
    if (exists("cancelClearLog")) $("cancelClearLog").addEventListener("click", () => { $("clearLog").classList.remove("hidden"); $("confirmClearLog").classList.add("hidden"); $("cancelClearLog").classList.add("hidden"); setStatus("logStatus", "기록 지우기를 취소했습니다."); });
    if (exists("confirmClearLog")) $("confirmClearLog").addEventListener("click", () => { state.logs = []; try { localStorage.removeItem(LOG_KEY); } catch {} renderLog(); $("clearLog").classList.remove("hidden"); $("confirmClearLog").classList.add("hidden"); $("cancelClearLog").classList.add("hidden"); setStatus("logStatus", "이 브라우저의 가상 활동기록을 지웠습니다. 외부 자료는 변경하지 않았습니다.", "success"); });

    const simulations = {
      simulateMissing: () => loadLearning(badLearningMissing, "오류 시뮬레이션: 열 누락"),
      simulateRange: () => loadLearning(badLearningRange, "오류 시뮬레이션: 범위"),
      simulateDate: () => loadTasks(badTaskDate, "오류 시뮬레이션: 날짜"),
      simulateRequired: () => loadTasks(badTaskRequired, "오류 시뮬레이션: 필수값"),
    };
    Object.entries(simulations).forEach(([id, handler]) => { if (exists(id)) $(id).addEventListener("click", handler); });
    if (exists("simulateApproval")) $("simulateApproval").addEventListener("click", () => {
      if (!state.learners.length || !exists("feedbackText") || !exists("approveFeedback")) { setStatus("recoveryStatus", "완성본에서 가상 자료를 불러온 뒤 피드백 승인 무효화를 연습하세요.", "error"); return; }
      $("approveFeedback").click();
      $("feedbackText").value += "\n[수정 시연] 이 문장을 추가했습니다.";
      $("feedbackText").dispatchEvent(new Event("input", { bubbles: true }));
      setStatus("recoveryStatus", "승인 뒤 문구를 바꾸어 이전 승인이 무효화되고 복사가 중단됐습니다.", "success");
    });
  }

  function initialize() {
    state.logs = safeLogsFromStorage();
    bindEvents();
    loadSamples(false);
    renderAll();
    if (exists("undoTask")) $("undoTask").disabled = true;
  }

  initialize();
})();
