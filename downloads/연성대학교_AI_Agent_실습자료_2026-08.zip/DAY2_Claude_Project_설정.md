# DAY 2 · Claude Team 실습 준비

내일 실습은 빈 화면에서 코드를 처음부터 만드는 과정이 아닙니다. 각 실습 폴더의 작동하는 작업본과 단계별 요청문을 이용해 한 기능씩 바꾸고, 직접 눌러 확인하는 과정입니다.

## 기본 경로: Claude Desktop · Cowork

1. Claude Desktop을 최신 버전으로 열고 학교 Team 작업공간을 선택합니다.
2. `Cowork`에서 실습 이름으로 새 Project를 만듭니다. 예: `실습 2 맞춤수업 도구`.
3. 폴더 선택 화면에서 실습 폴더 전체가 아니라 `내_작업` 폴더만 허용합니다.
4. 해당 실습의 `START_PROMPT.md`를 한 번 붙여 넣습니다.
5. Claude가 `CLAUDE_APP_바로시작.md`, `CLAUDE.md`, `PROJECT_INSTRUCTIONS.md`, `TASKS.md`, `CHECKLIST.md`를 읽고 작업 계획을 먼저 보여 주게 합니다.
6. 계획에서 현재 단계 하나만 승인합니다. 원본·완성본·가상자료 폴더는 수정하지 않습니다.
7. HTML 결과는 Live artifact로 열어 버튼과 입력을 직접 시험합니다. 별도 편집기나 개발자도구는 기본 실습에서 열지 않습니다.
8. 웹 화면이 필요하면 Claude in Chrome으로 열게 합니다. 로그인·비밀번호·인증번호는 본인이 직접 입력하고 권한 모드는 `Manually approve`(수동 승인)로 유지합니다.
9. 발송·예약·삭제·공개·공유는 대상과 내용을 다시 확인한 뒤 사람이 한 번만 승인하고, 취소·되돌리기 경로까지 확인합니다.

`claude://` 바로 시작 링크는 시작 요청을 미리 채워 줄 뿐 폴더 권한을 자동으로 주지 않습니다. 폴더는 반드시 본인이 화면에서 확인하고 `내_작업`만 선택합니다.

## 대체 경로: Claude 웹 Projects

Claude Desktop, Cowork 또는 Claude in Chrome이 조직에서 보이지 않을 때 사용합니다.

1. Claude 웹에서 `Projects → New Project`를 선택합니다.
2. 실습 폴더의 `PROJECT_INSTRUCTIONS.md` 전체를 Project instructions에 붙여 넣습니다.
3. `00_먼저읽기.html`이 안내하는 작업본과 가상 자료만 Project knowledge에 올립니다.
4. `TASKS.md`의 현재 단계 프롬프트 하나만 새 대화에 붙여 넣습니다.
5. 받은 파일은 원본을 덮어쓰지 말고 `내_작업`에 저장한 뒤 브라우저로 열어 확인합니다.

Claude 웹 Projects에서는 `CLAUDE.md`가 자동 적용되지 않습니다. 이 때문에 웹 대체 경로에는 `PROJECT_INSTRUCTIONS.md`가 별도로 포함되어 있습니다.

## 수업 후 확장: Claude Code

각 실습 폴더의 `CLAUDE.md`는 Claude Code가 해당 폴더에서 작업할 때 사용하는 프로젝트 지침입니다. 개발 환경과 명령 실행을 이해한 경우에만 선택합니다.

## 공통 작업 규칙

- 실제 학생 이름·학번·성적·연락처·상담 내용은 입력하지 않습니다.
- 실제 이메일 발송, 성적 변경, 외부 공개, 파일 삭제는 실습의 승인 단계 밖에서 실행하지 않습니다.
- 실습 1의 실제 발송은 본인 테스트 주소 1건으로 제한합니다.
- 시작본과 완성본은 참고용으로 보존하고 `내_작업`의 복사본만 수정합니다.
- 한 번에 한 단계만 요청합니다.
- 새 기능을 추가하기 전에 현재 기능을 직접 눌러 확인합니다.
- Claude의 설명보다 브라우저에서 실제로 작동하는지가 완료 기준입니다.

## 공통 복구 요청문

```text
지금부터 새 기능을 추가하지 마세요.
현재 작업 상태를 초보자도 이해할 수 있게 5줄로 요약하세요.
마지막으로 정상 작동한 파일과 지금 고장 난 기능을 구분하세요.
다음 행동은 하나만 제안하고, 제가 확인하기 전에는 파일을 수정하지 마세요.
실제 학생정보·외부 발송·공개·삭제는 수행하지 마세요.
```

## 파일 역할

- `00_먼저읽기.html`: 화면으로 보는 시작 안내
- `CLAUDE_APP_바로시작.md`: Claude Desktop·Cowork에서 화면을 보며 따라 할 순서
- `START_PROMPT.md`: 첫 대화에 한 번만 붙여 넣는 시작 요청
- `PROJECT_INSTRUCTIONS.md`: Claude 웹 Project instructions에 붙여 넣을 지침
- `CLAUDE.md`: 폴더 작업 범위·금지 행동·검사 기준
- `TASKS.md`: 단계별 복사 프롬프트와 멈춤 지점
- `CHECKLIST.md`: 정상·오류·복구 완료 확인
- `내_작업`: 참가자가 내려받은 새 파일을 저장할 위치
- `완성본`: 목표 화면과 기능을 확인하는 참고 자료

출처 · Anthropic, [How can I create and manage projects?](https://support.claude.com/en/articles/9519177-how-can-i-create-and-manage-projects)  
출처 · Anthropic, [Team·Enterprise의 Claude Cowork](https://support.claude.com/en/articles/13455879-use-claude-cowork-on-team-and-enterprise-plans)  
출처 · Anthropic, [Cowork Projects로 작업 정리](https://support.claude.com/en/articles/14116274-organize-your-tasks-with-projects-in-claude-cowork)  
출처 · Anthropic, [Cowork에서 Live artifacts 사용](https://support.claude.com/en/articles/14729249-use-live-artifacts-in-claude-cowork)  
출처 · Anthropic, [Claude in Chrome 시작하기](https://support.claude.com/en/articles/12012173-get-started-with-claude-in-chrome)  
출처 · Anthropic, [Claude in Chrome 권한 안내](https://support.claude.com/en/articles/12902446-claude-in-chrome-permissions-guide)
